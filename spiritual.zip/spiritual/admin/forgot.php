<?php 
session_start(); 
include("../includes/config.php");
if(isset($_POST['btn_submit'])){
	
	$error='';
	if(!strlen(trim($_POST['email']))) $error='Please enter Email Address';
	else{
		$sel_qry = "SELECT * FROM ".TABLE_ADMIN." WHERE email='".mysql_escape_string(stripslashes($_POST['email']))."'";
		$num = $db->fetchNum($sel_qry);
		if($num==0) $error='Invalid Email Address';
	}
	if($error==''){
		$row = $db->fetchRow($sel_qry);   
		$from = $row['email'];
		$to = $_POST['email'];
		$subject = 'Forgotten Password : '.SITE_NAME;
		$message='<table width="80%"  cellspacing="0" cellpadding="5" border="0" style="border:1px solid #d9d9d9" align="center">
					<tr>
					  <td style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-size:12px; padding:5px;background:#393939">Your Password Details from '.SITE_NAME.'</td>
					</tr>
					<tr>
						<td style="border-top:1px solid #d9d9d9;border-bottom:1px solid #d9d9d9">
							<table width="100%" cellspacing="0" cellpadding="5" border="0">
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Your Password
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$row['password'].'
									</td>                
								</tr>      
							</table>
						</td>
					</tr>
					<tr>
						<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px;background:#eeeeee; padding-right:10px; line-height:30px;">Regards,<br />'.SITE_NAME.' Team</td>
					</tr>
				</table>';
		
		$headers = "From: ".$from." <".$from.">\n";
		$headers .= "X-Sender: <".$from.">\n";
		$headers .= "X-Mailer: PHP\n"; // mailer
		$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
		$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
				
		$sent = mail($to,$subject,$message,$headers);
	
		$general->set_session_message('Success. Your password has been sent to your email address!');
		$general->redirect('forgot.php');
	}
}

$no_visible_elements=true;
include('includes/header.php'); ?>

			<div class="row-fluid">
				<div class="span12 center login-header">
					<h2>Welcome to <?php echo SITE_NAME;?></h2>
				</div><!--/span-->
			</div><!--/row-->
			
			<div class="row-fluid">
				<div class="well span5 center login-box">
					<div class="alert alert-info">
						<?php if(strlen(trim($error)) || isset($_SESSION['session_msg'])){ echo '<span style="color:#F00;">'.$_SESSION['session_msg'].$error.'</span>';} else {?>Enter the e-mail address associated with your account. Click submit to have your password e-mailed to you.<?php } ?>
					</div>
					<form class="form-horizontal" method="post">
						<fieldset>
							<div class="input-prepend" title="Username" data-rel="tooltip">
								<span class="add-on"><i class="icon-user"></i></span><input autofocus class="input-large span10" name="email" id="email" type="text" value="" />
							</div>
							<div class="clearfix"></div>

							
							<p class="center span5">
                            <a href="login.php" class="link">Login</a><br />
							<button type="submit" value="Submit" name="btn_submit" class="btn btn-primary">Submit</button>
							</p>
						</fieldset>
					</form>
				</div><!--/span-->
			</div><!--/row-->
<?php include('includes/footer.php'); ?>
