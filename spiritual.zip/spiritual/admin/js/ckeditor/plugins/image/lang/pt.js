﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'pt', {
	alertUrl: 'Por favor introduza o URL da imagem',
	alt: 'Texto Alternativo',
	border: 'Limite',
	btnUpload: 'Enviar para o Servidor',
	button2Img: 'Deseja transformar o botão com imagem selecionado em uma imagem?',
	hSpace: 'Esp.Horiz',
	img2Button: 'Deseja transformar a imagem selecionada em um botão com imagem?',
	infoTab: 'Informação da Imagem',
	linkTab: 'Hiperligação',
	lockRatio: 'Proporcional',
	menu: 'Propriedades da Imagem',
	resetSize: 'Tamanho Original',
	title: 'Propriedades da Imagem',
	titleButton: 'Propriedades do Botão de imagens',
	upload: 'Carregar',
	urlMissing: 'O URL da fonte da imagem está em falta.',
	vSpace: 'Esp.Vert',
	validateBorder: 'A borda tem de ser um numero.',
	validateHSpace: 'HSpace tem de ser um numero.',
	validateVSpace: 'VSpace tem de ser um numero.'
} );
