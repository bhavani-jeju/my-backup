<?php 
session_start(); 
include('../includes/config.php');
include('includes/check-session.php');
include('includes/header.php');
include('includes/pages.php');
include('includes/footer.php'); 
?>