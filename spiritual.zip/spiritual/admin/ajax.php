<?php 
include('../includes/config.php');
if(isset($_POST['action']) && $_POST['action']=='admin'){
	$q=mysql_query('select * from admin');
	$r=mysql_fetch_array($q);
echo $r['email'];
}
?>