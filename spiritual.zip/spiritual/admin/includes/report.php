 <div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php?p=newsletter">News Letter</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=send">Send Email</a><span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=report">Report</a>
	</ul>
</div>



<div class="row-fluid sortable">		

	<div class="box span12">

		<div class="box-header well" data-original-title>

			<h2><i class="icon-user"></i> Report</h2>

		</div>

		<div class="box-content">

			<table class="table table-striped table-bordered bootstrap-datatable datatable">

			  <thead>

				<tr>

				  <th>S.No.</th>

                  <th>Email Address</th>

                  <th>Subject</th>

		

				  <th class="center">Message</th>
				  <th>

		     Report:

		</th>

				</tr>

			  </thead>

			  <tbody>

				<?php

					  $content_select_query="SELECT * FROM reports ORDER BY id DESC";

					  $content_select_srows=$db->fetchNum($content_select_query);	

					  if($content_select_srows){					  

					  $j=1;

					  $content_select_res=$db->fetchResult($content_select_query);

					  while($content_select_srows=$db->fetchArray($content_select_res)) {

					?>

				<tr>

				  <td><?php echo $j++;?></td>

				  <td><?php echo $content_select_srows['email'];?></td>

				  <td>

				     <?php echo $content_select_srows['subject'];?>  

				  </td>

				  <td>

				     <?php echo $content_select_srows['message'];?>  

				  </td>

				  <td>

				       <?php 

				 if($content_select_srows['status']==1)

				 {

				      $s="mail send successfullly";

				 }

 else {

				 $s="mail sending failed";     

				 }

				       ?>

				       <?php echo $s;?>

				  </td>

				</tr>

				 <?php } } else { ?>

					<tr>

						<td colspan="4" align="center" style="color:#F00; font-weight:bold;">

							No records found

						</td>

					</tr>

				<?php } ?>

			  </tbody>

			</table>

		</div>

	</div><!--/span-->

	

</div><!--/row-->