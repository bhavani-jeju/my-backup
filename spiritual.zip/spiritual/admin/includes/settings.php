<?php
include("includes/classes/settings.php");
$obj_content=new content();
if(!isset($_POST['btn_email_submit'])){
	$data=$obj_content->getData(1);
	$_POST['email']=$data['email'];
}
if(isset($_POST['btn_pass_submit'])){
	$error=array();
	$error=$obj_content->checkPassData($_POST,1);
	if(count($error)==0){
			$obj_content->updatePassData($_POST,1);		
	}
}
if(isset($_POST['btn_email_submit'])){
	$error=array();
	$error=$obj_content->checkEmailData($_POST,1);
	if(count($error)==0){
		$obj_content->updateEmailData($_POST,1);		
	}
}
?>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Password updated successfully.<?php } else if($_GET['msg']==2) {?>Email Address updated successfully.<?php }else if($_GET['msg']==3) {?>Authorize.Net details updated successfully. <?php } ?>
	</div>
<?php } ?> 
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i>Profile Settings</h2>
		</div>
		<div class="box-content"> 			 
			<form id="edit" class="form-horizontal" name="frm" action="" method="post">
				<fieldset>
					<legend> Change Password</legend>
					<div class="control-group <?php if(strlen(trim($error['pass']))) echo 'error';?>">
						<label class="control-label">Enter New Password</label>
						<div class="controls">
							<input type="password" name="pass" class="input-xlarge focused" />   
							<?php if(strlen(trim($error['pass']))){?><span class="help-inline"><?php echo $error['pass'];?></span><?php } ?>
						</div>
					</div>
					<div class="control-group <?php if(strlen(trim($error['repass']))) echo 'error';?>">
						<label class="control-label">Confirm Password</label>
						<div class="controls">
							<input type="password" name="repass" class="input-xlarge focused" /> 
							<?php if(strlen(trim($error['repass']))){?><span class="help-inline"><?php echo $error['repass'];?></span><?php } ?>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_pass_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</fieldset>
			</form>
			
			 <form id="edit1" class="form-horizontal" name="frm1" action="" method="post">
				<fieldset>
					<legend> Change Email Address</legend>
					<div class="control-group <?php if(strlen(trim($error['email']))) echo 'error';?>">
						<label class="control-label">Email Address</label>
						<div class="controls">
							<input type="text" name="email" class="smallInput" value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>" /> 
							<?php if(strlen(trim($error['email']))){?><span class="help-inline"><?php echo $error['email'];?></span><?php } ?>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_email_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->