<?php
if(!isset($_GET['id']) && !$_GET['id']){
	echo "<script>location.replace('index.php?p=seo');</script>";
}
include("includes/classes/addseo.php");
$obj_content=new content();
if(isset($_GET['id']) && !isset($_POST['btn_submit'])){
	$_POST=$obj_content->getData((int)$_GET['id']);
}
if(isset($_POST['btn_submit'])){
	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	$obj_content->updateData($_POST,$id);	
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=addseo"><?php if(isset($_GET['id'])) echo 'Edit Meta Data'; else echo 'Add Meta Data';?></a>
		</li>
	</ul>
</div>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Meta Data'; else echo 'Add Meta Data';?></h2>
			<div class="box-icon">
				<a style="width:69px;" href="index.php?p=seo" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>
			</div>
		</div>
		<div class="box-content">	
			<fieldset>
				<form id="edit" class="form-horizontal" name="frm" action="" method="post">
					<div class="control-group">
						<label class="control-label">Page Title</label>
						<div class="controls">
							<input type="text" name="title" readonly="readonly" class="input-xlarge focused" value="<?php if(isset($_POST['title'])) echo $_POST['title'];?>" />
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">Meta Title</label>
						<div class="controls">
							<input type="text" name="mtitle" class="input-xlarge focused" value="<?php if(isset($_POST['mtitle'])) echo $_POST['mtitle'];?>" />
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">Meta Keywords</label>
						<div class="controls">
							<textarea  class="input-xlarge focused" name="mkey" rows="3"><?php if(isset($_POST['mkey'])) echo $_POST['mkey'];?></textarea>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">Meta Description</label>
						<div class="controls">
							<textarea class="input-xlarge focused" name="mdesc" rows="3"><?php if(isset($_POST['mdesc'])) echo $_POST['mdesc'];?></textarea>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</form>
			<fieldset>
		</div>
	</div><!--/span-->
</div><!--/row-->