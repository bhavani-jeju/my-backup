<?php
include("includes/classes/commission.php");
$obj_content=new content();
if(!isset($_POST['btn_commission_submit'])){
	$data=$obj_content->getData(1);
	$_POST['commission']=$data['commission'];
}
if(!isset($_POST['btn_discount_submit'])){
	$data=$obj_content->getDiscountData(1);
	$_POST['discount']=$data['discount'];
	$_POST['discount1']=$data['discount1'];
}

if(isset($_POST['btn_commission_submit'])){
	$error=array();
	$error=$obj_content->checkEmailData($_POST,1);
	if(count($error)==0){
		$obj_content->updateEmailData($_POST,1);		
	}
}
if(isset($_POST['btn_discount_submit'])){
	$error=array();
	$error=$obj_content->checkDiscountData($_POST,1);
	if(count($error)==0){
		$obj_content->updateDiscountData($_POST,1);		
	}
}
?>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Price updated successfully.<?php } else if($_GET['msg']==2) {?>Commission updated successfully.<?php } else if($_GET['msg']==3) {?>Discount  updated successfully.<?php } ?>
	</div>
<?php } ?> 
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i>Price Manipulation</h2>
		</div>
		<div class="box-content"> 			 
			
			
			 <form id="edit1" class="form-horizontal" name="frm1" action="" method="post">
				<fieldset>
					<legend> Commission</legend>
					<div class="control-group <?php if(strlen(trim($error['commission']))) echo 'error';?>">
						<label class="control-label">Commission (%)</label>
						<div class="controls">
							<input type="text" name="commission" class="smallInput" value="<?php if(isset($_POST['commission'])) echo $_POST['commission'];?>" /> 
							<?php if(strlen(trim($error['commission']))){?><span class="help-inline"><?php echo $error['commission'];?></span><?php } ?>
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_commission_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</fieldset>
			</form>
            
			 <form id="edit1" class="form-horizontal" name="frm1" action="" method="post">
				<fieldset>
					<legend> Cash Back Discount</legend>
					<div class="control-group <?php if(strlen(trim($error['discount']))) echo 'error';?>">
						<label class="control-label">Discount (%)</label>
						<div class="controls">
							<input type="text" name="discount" class="smallInput" value="<?php if(isset($_POST['discount'])) echo $_POST['discount'];?>" /> 
							<?php if(strlen(trim($error['discount']))){?><span class="help-inline"><?php echo $error['discount'];?></span><?php } ?>
						</div>
					</div>
                   
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_discount_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->