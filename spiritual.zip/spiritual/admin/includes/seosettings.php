<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=seo">SEO Settings</a>
		</li>
	</ul>
</div>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Page added successfully.<?php } else if($_GET['msg']==2) {?>Page updated successfully.<?php }else if($_GET['msg']==3) {?>Page deleted successfully. <?php } ?>
	</div>
<?php } ?>       
<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-user"></i> Pages SEO Management</h2>
		</div>
		<div class="box-content">
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
			  <thead>
				<tr>
				  <th>S.No</th>
				  <th>Page Name</th>
				  <th>Meta Title</th>
				  <th>Meta Keywords</th>
				  <th>Meta Description</th>
				  <th>Actions</th>
				</tr>
			  </thead>
			  <tbody>
				<?php
					  $content_select_query="SELECT * FROM ".TABLE_CONTENT;
					  $content_select_srows=$db->fetchNum($content_select_query);	
					  if($content_select_srows){					  
					  $j=1;
					  $content_select_res=$db->fetchResult($content_select_query);
					  while($content_select_srows=$db->fetchArray($content_select_res)) {
					?>
				<tr>
				  <td><?php echo $j++;?></td>
				  <td><?php echo $content_select_srows['title'];?></td>
				  <td><?php echo $content_select_srows['mtitle'];?></td>
				  <td><?php echo $content_select_srows['mdesc'];?></td>
				  <td><?php echo $content_select_srows['mkey'];?></td>
				  <td class="center"> <a class="btn btn-info" href="index.php?p=addseo&id=<?php echo $content_select_srows['id'];?>">
										<i class="icon-edit icon-white"></i>  
										Edit                                            
									</a>
									</td>
				</tr>
				 <?php } } else { ?>
					<tr>
						<td colspan="6" align="center" style="color:#F00; font-weight:bold;">
							No records found
						</td>
					</tr>
				<?php } ?>
			  </tbody>
			</table>
		</div>
	</div><!--/span-->
	
</div><!--/row-->