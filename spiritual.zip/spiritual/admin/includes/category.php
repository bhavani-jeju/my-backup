<?php
include("includes/classes/category.php");
$obj_content=new content();
if(isset($_GET['id']) && !isset($_POST['btn_submit'])){
	$_POST=$obj_content->getData((int)$_GET['id']);
}
if(isset($_POST['btn_submit'])){
	$error="";
	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	$error=$obj_content->checkData($_POST,$id);
	if($error==""){
		if(isset($_GET['id']))
			$obj_content->updateData($_POST,$id);
		else 
			$obj_content->insertData($_POST);
	}
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=category<?php if(isset($_GET['id']) && (int)$_GET['id']) echo '&id='.(int)$_GET['id'];?>"><?php if(isset($_GET['id'])) echo 'Edit Category'; else echo 'Add Category';?></a>
		</li>
	</ul>
</div>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Category'; else echo 'Add Category';?></h2>
			<div class="box-icon">
				<a style="width:69px;" href="index.php?p=categories" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>
			</div>
		</div>
		<div class="box-content">			 
			<form id="edit" class="form-horizontal" name="frm" action="" method="post" enctype="multipart/form-data">
				<fieldset>
					<div class="control-group <?php if(strlen(trim($error))) echo 'error';?>">
						<label class="control-label">Category title</label>
						<div class="controls">
							<input type="text" name="title" value="<?php if(isset($_POST['title'])) echo $_POST['title'];?>" class="input-xlarge focused" />
							<?php if(strlen(trim($error))){?><span class="help-inline"><?php echo $error;?></span><?php } ?>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">Parent Category</label>
						<div class="controls">
							<select  data-rel="chosen" name="parent">
								<option value="">Select Parent</option>
								<?php $toplink=$db->fetchResult("SELECT * FROM ".TABLE_CATEGORIES." where parent=0 order by id"); while($top=$db->fetchArray($toplink)){ ?>
								<option value="<?php echo $top['id'];?>" <?php if($top['id']==$_POST['parent']) echo 'selected="selected"';?>><?php echo str_replace("_"," ",$top['title']);?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="control-group">
					  <label class="control-label">URL Alias Name</label>
					  <div class="controls">
						<?php 
							if(isset($_GET['id']) && (int)$_GET['id']){ 
								$query='category_id='.(int)$_GET['id'];
								$alias_row=$db->fetchRow("SELECT * FROM ".TABLE_ALIAS." WHERE query='".$query."'"); 
								$_POST['keyword']=$alias_row['keyword'];
							}
							else $_POST['keyword']='';							
						?>
						<input type="text" name="keyword" class="input-xlarge focused" value="<?php if(isset($_POST['keyword'])) echo $_POST['keyword'];?>">
					  </div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>	
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->