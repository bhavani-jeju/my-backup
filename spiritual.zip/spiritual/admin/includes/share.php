<?php
include("includes/classes/share.php");
$obj_content=new content();
if(!isset($_POST['btn_submit'])){
	$_POST=$obj_content->getData(1);
}
if(isset($_POST['btn_submit'])){
	$obj_content->updateData($_POST,1);
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=share">Share Icons</a>
		</li>
	</ul>
</div>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Share Icons updated successfully.<?php } ?>
	</div>
<?php } ?> 
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i>Share Icons</h2>
		</div>
		<div class="box-content"> 			 
			<form id="edit" class="form-horizontal" name="frm" action="" method="post">
				<fieldset>
					<div class="control-group">
					  <label class="control-label">Facebook</label>
					  <div class="controls">
						<input type="text" name="facebook" class="input-xlarge focused" value="<?php if(isset($_POST['facebook'])) echo $_POST['facebook'];?>">
					  </div>
					</div>			
                    <div class="control-group">
					  <label class="control-label">Twitter</label>
					  <div class="controls">
						<input type="text" name="twitter" class="input-xlarge focused" value="<?php if(isset($_POST['twitter'])) echo $_POST['twitter'];?>">
					  </div>
					</div>			
                    <div class="control-group">
					  <label class="control-label">Youtube</label>
					  <div class="controls">
						<input type="text" name="youtube" class="input-xlarge focused" value="<?php if(isset($_POST['youtube'])) echo $_POST['youtube'];?>">
					  </div>
					</div>			
                    <div class="control-group">
					  <label class="control-label">Google Plus</label>
					  <div class="controls">
						<input type="text" name="gplus" class="input-xlarge focused" value="<?php if(isset($_POST['gplus'])) echo $_POST['gplus'];?>">
					  </div>
					</div>			
                    <div class="control-group">
					  <label class="control-label">LinkedIn</label>
					  <div class="controls">
						<input type="text" name="linkedin" class="input-xlarge focused" value="<?php if(isset($_POST['linkedin'])) echo $_POST['linkedin'];?>">
					  </div>
					</div>		
                    <div class="control-group">
					  <label class="control-label">Rss Feed</label>
					  <div class="controls">
						<input type="text" name="rssfeed" class="input-xlarge focused" value="<?php if(isset($_POST['rssfeed'])) echo $_POST['rssfeed'];?>">
					  </div>
					</div>					
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>					
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->