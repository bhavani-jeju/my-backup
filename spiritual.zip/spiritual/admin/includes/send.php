<?php 
		if(isset($_POST['btn_submit'])){
		$a=  implode($_POST['email'],',');
		if($a=='')
		{
			$q1="select * from newsletter  where status=".(int)1;
			$res1=mysql_query($q1);
			while($row1=mysql_fetch_array($res1)){
			$to=$row1['email'];
			 $message=$_POST['txtmsg'];
		     $subject=$_POST['sub'];
			 //$from="bhavanikiet1246@gmail.com"; 
			 $q=mysql_query("select * from admin");
			 $r=mysql_fetch_array($q);
			 $from=$r['admin'];
			$headers = "From: ".$from." <".$from.">\n";
	$headers .= "X-Sender: <".$from.">\n";
	$headers .= "X-Mailer: PHP\n"; // mailer
	$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
	$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mim
	$sent=mail($to, $subject, $message,$headers);
		if($sent)
			{
			$i=1;
			$q = "insert into reports set subject='".mysql_escape_string(stripslashes($subject))."',message='".mysql_escape_string(stripslashes($message))."',email='".mysql_escape_string(stripslashes($to))."',status='".$i."'";
			$res=$db->fetchResult($q);
			if($res){
			
			   $suc="mail send successfully";
			}
			}
		 else {
			$suc="mail1 sending failed"     ;
			}
			}
		}
		else
		{
		     $message=$_POST['txtmsg'];
		     $subject=$_POST['sub'];
		     $a=  implode($_POST['email'],',');
		     $k=  rtrim($a,',');
		    $ar=explode(',',$k);
			$from="bhavanikiet1246@gmail.com"; 
			$headers = "From: ".$from." <".$from.">\n";
	$headers .= "X-Sender: <".$from.">\n";
	$headers .= "X-Mailer: PHP\n"; // mailer
	$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
	$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
		    foreach ($ar as $x)
		    {
			$sent=mail($x, $subject, $message,$headers);
			if($sent)
			{
			$i=1;
			$q = "insert into reports set subject='".mysql_escape_string(stripslashes($subject))."',message='".mysql_escape_string(stripslashes($message))."',email='".mysql_escape_string(stripslashes($x))."',status='".$i."'";
			$res=$db->fetchResult($q);
			if($res){
			
			   $suc="mail send successfully";
			}
			}
		 else {
			$suc="mail sending failed"     ;
			}
		    }
		}
		}
?>
<html>
<head>
     <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
   <script type="text/javascript">
     $(document).ready(function(){
         $('#send').click(function(){
   	   var errr=0;
           $('.error').hide();
	          if($('#txtmsg').val()==''){
               $('#s').html('<span class="error" style="color:#F00;">* Enter Message</span>');
               errr=1;
            }
	            if($('#sub').val()==''){
               $('#s').html('<span class="error" style="color:#F00;">* Enter Subject</span>');
          
           if($('#to').val()==''){
               $('#s').html('<span class="error" style="color:#F00;">* Enter Email Address</span>');
               errr=1;
            } 
       
               errr=1;
            } 
	  
	     if(errr==1)
               return false;
	       else{
	    return true;
               }
	    });
     });
</script>  
</head>
<body>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php?p=newsletter">News Letter</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=send">Send Email</a><span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=report">Report</a>
	</ul>
</div>
<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-user"></i> Send Items</h2>
			
		</div>
	     <form method="post">
	     <div class="box-content">

<span style="color: red" id='s'><?php echo $suc;?></span>

<fieldset style="width: 350px;">
	    <legend> </legend>

	    <table cellpading="10" cellspacing="5">
		
		<tr>
		    <th align='left'>To:</th>
		<td>
		     <select class="email" name="email[]" style="width: 610px;" multiple data-rel="chosen">
			 <option value=''>select all</option>
	    <?php 
	    $x=1;
	    $q="select * from newsletter  where status=".$x;
	    $res=  mysql_query($q);
	    while($row=mysql_fetch_array($res)){?>
	    <option value="<?php echo $row['email']?>">
	    <?php echo $row['email']?>
	    </option>
	    <?php }?>
		    </select></td>
	    </tr><tr></tr>
	    <tr>
	    <tr>
		<th  align='left'>Subject:</th>
		<td><input type="text" name='sub' id="sub" style="width:600px;"></th>
	    </tr><tr></tr>
	    <tr>
		<th  align='left'>Message:</th>
	<td><textarea name="txtmsg" id="txtmsg"style="height: 220px;width: 600px;"></textarea></td>
	    </tr>
	    
	   </table>
	    <center><div class="controls">
		     <button   type="submit" name="btn_submit" value="submit" class="btn btn-primary" id="send">Send</button>
		</div></center>
		</div>
		 </form>
	</div><!--/span-->
</div><!--/row-->
</body>
</html>