<?php
 
if(isset($_GET['p'])) $p=$_GET['p']; else $p="";

switch($p){
case "Dell" 		: include("includes/Dell.php"); break;
case "newsletter" 		: include("includes/newsletter.php"); break;
case "send" 		: include("includes/send.php"); break;
case "report" 		: include("includes/report.php"); break;
case "commission" 		: include("includes/commission.php"); break;

case "company" 		: include("includes/company.php"); break;

	case "companys" 	: include("includes/companys.php"); break;
	case "content" 		: include("includes/content.php"); break;

	case "contents" 	: include("includes/contents.php"); break;

	case "hsettings" 	: include("includes/hsettings.php"); break;
	case "settings" 	: include("includes/settings.php"); break;

	case "seo" 			: include("includes/seosettings.php"); break;
	case "merchant" 			: include("includes/merchant.php"); break;
	case "emerchant" 			: include("includes/emerchant.php"); break;
	case "addseo" 		: include("includes/addseo.php"); break;

	case "products" 	: include("includes/productlist.php"); break;
	case "productlist" 	: include("includes/productlist.php"); break;

	case "product" 		: include("includes/product.php"); break;

	case "categories" 	: include("includes/categories.php"); break;

	case "category" 	: include("includes/category.php"); break;

	case "brands" 		: include("includes/brands.php"); break;

	case "brand" 		: include("includes/brand.php"); break;
	case "samples" 		: include("includes/samples.php"); break;

	case "sample" 		: include("includes/sample.php"); break;


	case "pgs" 			: include("includes/pgs.php"); break;

	case "shippings" 	: include("includes/shippings.php"); break;

	case "shipping" 	: include("includes/shipping.php"); break;

	case "orders" 		: include("includes/orders.php"); break;

	case "order" 		: include("includes/order.php"); break;

	case "users" 		: include("includes/users.php"); break;

	case "user" 		: include("includes/user.php"); break;

	case "subscribers" 	: include("includes/subscribers.php"); break;

	case "compose" 		: include("includes/compose.php"); break;

	case "testimonials" : include("includes/testimonials.php"); break;

	case "testimonial"  : include("includes/testimonial.php"); break;

	case "news" 		: include("includes/news.php"); break;

	case "addnews" 		: include("includes/addnews.php"); break;

	case "banners" 		: include("includes/banners.php"); break;

	case "banner" 		: include("includes/banner.php"); break;

	case "articles" 	: include("includes/articles.php"); break;

	case "article" 		: include("includes/article.php"); break;

	case "coupons" 		: include("includes/coupons.php"); break;

	case "coupon" 		: include("includes/coupon.php"); break;

	case "share" 		: include("includes/share.php"); break;

	case "commission" 	: include("includes/commission.php"); break;
	
	case "pdf" 	: include("includes/export_pdf.php"); break;	
	case "pdfdown" 	: include("includes/pdf_down.php"); break;	 

	

	default				: include("includes/productlist.php"); break; 

}

?>



