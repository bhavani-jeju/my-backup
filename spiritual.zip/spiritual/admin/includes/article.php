<?php
include("includes/classes/article.php");
$obj_content=new content();
if(isset($_GET['id']) && !isset($_POST['btn_submit'])){
	$_POST=$obj_content->getData((int)$_GET['id']);
}
if(isset($_POST['btn_submit'])){
	$error="";
	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	$error=$obj_content->checkData($_POST,$id);
	if($error==""){
		if(isset($_GET['id']))
			$obj_content->updateData($_POST,$id);
		else 
			$obj_content->insertData($_POST);
	}
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=article<?php if(isset($_GET['id']) && (int)$_GET['id']) echo '&id='.(int)$_GET['id'];?>"><?php if(isset($_GET['id'])) echo 'Edit Article'; else echo 'Add Article';?></a>
		</li>
	</ul>
</div>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Article'; else echo 'Add Article';?></h2>
			<div class="box-icon">
				<a style="width:69px;" href="index.php?p=articles" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>
			</div>
		</div>
		<div class="box-content">			 
			<form id="edit" class="form-horizontal" name="frm" action="" method="post" enctype="multipart/form-data">
				<fieldset>
					<div class="control-group <?php if(strlen(trim($error))) echo 'error';?>">
						<label class="control-label">Article title</label>
						<div class="controls">
							<input type="text" name="title" value="<?php if(isset($_POST['title'])) echo $_POST['title'];?>" class="input-xlarge focused" />
							<?php if(strlen(trim($error))){?><span class="help-inline"><?php echo $error;?></span><?php } ?>
						</div>
					</div>	
                    <div class="control-group <?php if(strlen(trim($error))) echo 'error';?>">
						<label class="control-label">Article Link</label>
						<div class="controls">
							<input type="text" name="links" value="<?php if(isset($_POST['links'])) echo $_POST['links'];?>" class="input-xlarge focused" />
							<?php if(strlen(trim($error))){?><span class="help-inline"><?php echo $error;?></span><?php } ?>
						</div>
					</div>
                    <div class="control-group <?php if(strlen(trim($error))) echo 'error';?>">
						<label class="control-label">Article Written By</label>
						<div class="controls">
							<input type="text" name="user" value="<?php if(isset($_POST['user'])) echo $_POST['user'];?>" class="input-xlarge focused" />
							<?php if(strlen(trim($error))){?><span class="help-inline"><?php echo $error;?></span><?php } ?>
						</div>
					</div>						
					<div class="control-group">
					  <label class="control-label">URL Alias Name</label>
					  <div class="controls">
						<?php 
							if(isset($_GET['id']) && (int)$_GET['id']){ 
								$query='brand_id='.(int)$_GET['id'];
								$alias_row=$db->fetchRow("SELECT * FROM ".TABLE_ALIAS." WHERE query='".$query."'"); 
								$_POST['keyword']=$alias_row['keyword'];
							}
							else $_POST['keyword']='';							
						?>
						<input type="text" name="keyword" class="input-xlarge focused" value="<?php if(isset($_POST['keyword'])) echo $_POST['keyword'];?>">
					  </div>
					</div>
                    <div class="control-group <?php if(strlen(trim($error['bimage']))) echo 'error';?>">
						<label class="control-label">Article  image</label>
						<div class="controls">
							<input type="file" name="bimage" class="smallInput" />
							<?php if(strlen(trim($error['bimage']))){?><span class="help-inline"><?php echo $error['bimage'];?></span><?php } ?>
							<?php if(file_exists('../images/articles/img'.$_POST['bimage'])){?><div class="product_image"  style="width:20px;"><img src="../images/articles/img<?php echo $_POST['bimage'];?>" width="20" height="20" /><input type="hidden" name="bimage" value="<?php echo $_POST['bimage'];?>" /></div><?php } ?>
						</div>
					</div>
                    <div class="control-group">
						<label class="control-label">Article  Description</label>
						<div class="controls">
                        <textarea class="ckeditor" id="editor1" name="description" rows="3"><?php if(isset($_POST['description'])) echo $_POST['description'];?></textarea>

							</div> 
						</div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>	
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->