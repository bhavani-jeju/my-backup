<?php
if(isset($_GET['id']) && (int)$_GET['id'] && $_GET['act']=="del"){
	$delete="delete from ".TABLE_CONTENT." where id=".(int)$_GET['id'];
	$db->fetchResult($delete);
	echo "<script>location.replace('index.php?p=contents&msg=3');</script>";
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=contents">Pages</a>
		</li>
	</ul>
</div>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Page added successfully.<?php } else if($_GET['msg']==2) {?>Page updated successfully.<?php }else if($_GET['msg']==3) {?>Page deleted successfully. <?php } ?>
	</div>
<?php } ?>       
<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-user"></i> Pages Management</h2>
			<div class="box-icon">
				<a href="index.php?p=content" style="width:70px;" class="ajax-link btn btn-add btn-round"><i class="icon-plus"></i>Add Page</a>
			</div>
		</div>
		<div class="box-content">
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
			  <thead>
				<tr>
				  <th>S.No</th>
				  <th>Page Title</th>
				  <th>Parent Page</th>
				  <th>Location</th>
				  <th class="center">Order</th>
				  <th class="center">Actions</th>
				</tr>
			  </thead>
			  <tbody>
				<?php
					  $content_select_query="SELECT * FROM ".TABLE_CONTENT." ORDER BY id DESC";
					  $content_select_srows=$db->fetchNum($content_select_query);	
					  if($content_select_srows){					  
					  $j=1;
					  $content_select_res=$db->fetchResult($content_select_query);
					  while($content_select_srows=$db->fetchArray($content_select_res)) {
					?>
				<tr>
				  <td><?php echo $j++;?></td>
				  <td><?php echo $content_select_srows['title'];?></td>
				  <td><?php $parent_select_res=$db->fetchResult("select title from ".TABLE_CONTENT." where id=".(int)$content_select_srows['parent']); 
							$parent_select_srows=$db->fetchArray($parent_select_res);
							if(strlen(trim($parent_select_srows['title']))) echo $parent_select_srows['title']; else echo '----';
					  ?>
				  </td>
				  <td><?php if($content_select_srows['header']==1) echo ' -- Header -- '; if($content_select_srows['footer']==1) echo ' -- Footer -- ';?></td>
				  <td class="center"><?php echo $content_select_srows['ord'];?></td>
				  <td class="center"> <a class="btn btn-info" href="index.php?p=content&id=<?php echo $content_select_srows['id'];?>">
										<i class="icon-edit icon-white"></i>  
										Edit                                            
									</a>
									<a class="btn btn-danger" href="index.php?p=contents&id=<?php echo $content_select_srows['id'];?>&act=del" onclick="if(!confirm('Are you sure you want to delete this page.')) return false;">
										<i class="icon-trash icon-white"></i> 
										Delete
									</a></td>
				</tr>
				 <?php } } else { ?>
					<tr>
						<td colspan="6" align="center" style="color:#F00; font-weight:bold;">
							No records found
						</td>
					</tr>
				<?php } ?>
			  </tbody>
			</table>
		</div>
	</div><!--/span-->
	
</div><!--/row-->      