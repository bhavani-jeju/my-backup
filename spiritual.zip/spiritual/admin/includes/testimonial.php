<?php
include("includes/classes/testimonial.php");
$obj_content=new content();
if(isset($_GET['id']) && !isset($_POST['btn_submit'])){
	$_POST=$obj_content->getData((int)$_GET['id']);
}
if(isset($_POST['btn_submit'])){
	$error=array();
	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	$error=$obj_content->checkData($_POST,$id);
	if(count($error)==0){
		if(isset($_GET['id']))
			$obj_content->updateData($_POST,$id);
		else 
			$obj_content->insertData($_POST);
	}
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=testimonial<?php if(isset($_GET['id']) && (int)$_GET['id']) echo '&id='.(int)$_GET['id'];?>"><?php if(isset($_GET['id'])) echo 'Edit Testimonial'; else echo 'Add Testimonial';?></a>
		</li>
	</ul>
</div>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Testimonial'; else echo 'Add Testimonial';?></h2>
			<div class="box-icon">
				<a style="width:69px;" href="index.php?p=testimonials" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>
			</div>
		</div>
		<div class="box-content">			 
			<form id="edit" class="form-horizontal" name="frm" action="" method="post" enctype="multipart/form-data">
				<fieldset>
					<div class="control-group <?php if(strlen(trim($error['clientname']))) echo 'error';?>">
						<label class="control-label">Client Name</label>
						<div class="controls">
							<input type="text" name="clientname" value="<?php if(isset($_POST['clientname'])) echo $_POST['clientname'];?>" class="input-xlarge focused" />
							<?php if(strlen(trim($error['clientname']))){?><span class="help-inline"><?php echo $error['clientname'];?></span><?php } ?>
						</div>
					</div>
					<div class="control-group <?php if(strlen(trim($error['testimonial']))) echo 'error';?>">
						<label class="control-label">Testimonial</label>
						<div class="controls">
							<textarea name="testimonial" class="input-xlarge focused"><?php if(isset($_POST['testimonial'])) echo $_POST['testimonial'];?></textarea>
							<?php if(strlen(trim($error['testimonial']))){?><span class="help-inline"><?php echo $error['testimonial'];?></span><?php } ?>
						</div>
					</div>
					
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>	
				</fieldset>
			</form>
		</div>
	</div><!--/span-->
</div><!--/row-->