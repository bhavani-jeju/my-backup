<?php

function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);

					

		if(!strcmp("png",$ext))

			$src_img=imagecreatefrompng($img_name);

			

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}



class content{

	function getData($id){

		global $db;

		$select="select * from coupons where id=".(int)$id;

		$data=$db->fetchRow($select);

		return $data;

	}

	function checkData($data,$id){

		global $db; $error=array();

		if(!strlen(trim($data['title']))) $error['title']='Please enter Title.<br />';		
	
	

		if($id){

			if(strlen(trim($_FILES['cimg']['name']))){

				$ext=substr(strrchr($_FILES['cimg']['name'],'.'),1);

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['img']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}

		else {

		if(!strlen(trim($_FILES['cimg']['name']))) $error['img']='Browse the main image to upload.<br />';

			else{

				$ext=substr(strrchr($_FILES['cimg']['name'],'.'),1);

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['img']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}

		return $error;

	}

	function insertData($data){

		global $db;		

						

		$insert="insert into coupons set title='".mysql_escape_string(stripslashes($data['title']))."', content='".mysql_escape_string(stripslashes($data['content']))."',cid='".(int)$data['cid']."',sterms='".mysql_escape_string(stripslashes($data['sterms']))."'";

										

		$reuslt=$db->fetchResult($insert);

		$id = mysql_insert_id();

		

		$cimg=$_FILES['cimg']['name'];

		$ext=substr(strrchr($cimg,'.'),1);

				

		$img1="../images/coupons/imga".$id.".".$ext;

		 

		if(move_uploaded_file($_FILES['cimg']['tmp_name'], $img1))

		{			

			$thumb=make_thumb($img1,$img1,998,380,$ext);

		}

		

		$mainimage=$id.'.'.$ext;

		

		$update="update coupons set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

		$reuslt=$db->fetchResult($update);
		for($i=1;$i<=4;$i++){		

			if(strlen(trim($_FILES['simg'.$i]['name']))){

				$simg = $_FILES['simg'.$i]['name'];

				$ext=strtolower(substr(strrchr($simg,'.'),1));

				$img1='../images/coupons/img'.$id.'-'.$i.'.'.$ext;

				$img2="../images/coupons/img".$id.'-'.$i.'.'.$ext;

				$img3="../images/coupons/img".$id.'-'.$i.'.'.$ext;

				$img4="../images/coupons/img".$id.'-'.$i.'.'.$ext;

				

				$subimg=$id.'-'.$i.'.'.$ext;

				if(move_uploaded_file($_FILES['simg'.$i]['tmp_name'],$img1)){					

					$thumb=make_thumb($img1,$img2,202,305,$ext);

					$thumb=make_thumb($img1,$img3,202,305,$ext);

					$thumb=make_thumb($img1,$img4,202,305,$ext);

				}					

				$subimg=$id.'-'.$i.'.'.$ext;

				$subimage='subimage'.$i;

				$update="update coupons set $subimage = '".mysql_escape_string(stripslashes($subimg))."' where id=".$id;

				$reuslt1=$db->fetchResult($update);

			}

		}
		
$f1=$_FILES['pdf_file']['name'];

		 $ext=substr(strrchr($f1,'.'),1);
		 
      		

		$file="../images/couponpdf/".$id.".".$ext;

		
$file;
		if(move_uploaded_file($_FILES['pdf_file']['tmp_name'],$file)){
			 $file=$id.'.'.$ext;
			    
 $update="update coupons set pdf_file = '".$file."' where id=".$id;

				$reuslt2=$db->fetchResult($update);
		}
		
if(strlen(trim($_POST['keyword']))){
				$id=mysql_insert_id();
				global $alias;
				$query ='coupon_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));
				$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}		
		

		if($reuslt)  echo "<script>location.replace('index.php?p=coupons&msg=1');</script>";	

	

	}

	

	function updateData($data,$id){

		global $db;		

		

		$cimg=$_FILES['cimg']['name'];

		$ext=substr(strrchr($cimg,'.'),1);

			

		$img1="../images/coupons/imga".$id.".".$ext;

		$mainimage=$id.'.'.$ext;

		if(move_uploaded_file($_FILES['cimg']['tmp_name'],$img1)){

			$thumb=make_thumb($img1,$img1,998,380,$ext);

			$update="update coupons set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

			$db->fetchResult($update);	

		}

        		   			

		$update="update coupons set title='".mysql_escape_string(stripslashes($data['title']))."', content='".mysql_escape_string(stripslashes($data['content']))."',cid='".(int)$data['cid']."',sterms='".mysql_escape_string(stripslashes($data['sterms']))."'  where id=".$id;				  

																					

		$reuslt=$db->fetchResult($update);
		for($i=1;$i<=4;$i++){		

				if(strlen(trim($_FILES['simg'.$i]['name']))){

					$simg = $_FILES['simg'.$i]['name'];

					$ext=strtolower(substr(strrchr($simg,'.'),1));

					$img1='../images/coupons/img'.$id.'-'.$i.'.'.$ext;

					$img2="../images/coupons/img".$id.'-'.$i.'.'.$ext;

					$img3="../images/coupons/img".$id.'-'.$i.'.'.$ext;

					$img4="../images/coupons/img".$id.'-'.$i.'.'.$ext;

					

					$subimg=$id.'-'.$i.'.'.$ext;

					if(move_uploaded_file($_FILES['simg'.$i]['tmp_name'],$img1)){					

						$thumb=make_thumb($img1,$img2,202,305,$ext);

						$thumb=make_thumb($img1,$img3,202,305,$ext);

						$thumb=make_thumb($img1,$img4,202,305,$ext);

					}					

					$subimg=$id.'-'.$i.'.'.$ext;

					$subimage='subimage'.$i;

					$update="update coupons set $subimage = '".mysql_escape_string(stripslashes($subimg))."' where id=".$id;

					$reuslt1=$db->fetchResult($update);
					
				}
		}
					
			$f1=$_FILES['pdf_file']['name'];
echo $f1;
		 $ext=substr(strrchr($f1,'.'),1);

			

		$f1=$_FILES['pdf_file']['name'];

		 $ext=substr(strrchr($f1,'.'),1);
		 
      		

		$file="../images/couponpdf/".$id.".".$ext;

		
$file;
		if(move_uploaded_file($_FILES['pdf_file']['tmp_name'],$file)){
			 $file=$id.'.'.$ext;
			    
 $update="update coupons set pdf_file = '".$file."' where id=".$id;

				$reuslt2=$db->fetchResult($update);
		}
		if($reuslt){
			if(strlen(trim($_POST['keyword']))){				
				global $alias;
				$query ='coupon_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);
				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'"))
					$res="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";
				else
					$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}

			echo "<script>location.replace('index.php?p=coupons&msg=2');</script>";

		 }
		}
	
	
}

?>