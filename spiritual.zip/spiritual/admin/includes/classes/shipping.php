<?php
class content{

	function getData($id){
		global $db;
		$select="select * from ".TABLE_SHIPPING." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkData($data,$id){
		global $db; $error=array();
		if(!strlen(trim($data['country']))) $error['country']='Please select Country.<br />';
		else{
			if($id) $subquery=" and id<>".$id; else $subquery="";
			$select="select id from ".TABLE_SHIPPING." where country='".mysql_escape_string(stripslashes($data['country']))."' and port='".mysql_escape_string(stripslashes($data['port']))."' $subquery";
			$num=$db->fetchNum($select);
			if($num) $error['port']='Port already exists.<br />';
		}
		if(!strlen(trim($data['port']))) $error['port']='Please enter Port.<br />';
		if(!strlen(trim($data['cost']))) $error['cost']='Please enter Price.<br />';
		else if (!is_numeric ($data['cost'])) $error['cost']='Please enter valid price.<br/>';
		
		return $error;
	}
	
	function insertData($data){
		global $db;
		$insert="insert into ".TABLE_SHIPPING." set country='".mysql_escape_string(stripslashes($data['country']))."', port='".mysql_escape_string(stripslashes($data['port']))."', cost='".(float)$data['cost']."'";
		$reuslt=$db->fetchResult($insert);
		if($reuslt){		    		
			echo "<script>location.replace('index.php?p=shippings&msg=1');</script>";
		}
	}
	
	function updateData($data,$id){
		global $db;
		$update="update ".TABLE_SHIPPING." set country='".mysql_escape_string(stripslashes($data['country']))."', port='".mysql_escape_string(stripslashes($data['port']))."', cost='".(float)$data['cost']."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt){		  
		 	echo "<script>location.replace('index.php?p=shippings&msg=2');</script>";
		}
	}
}
?>