<?php
class content{
	function getData($id){
		global $db;
		$select="select commission from ".TABLE_ADMIN." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	function getDiscountData($id){
		global $db;
		$select="select discount,discount1 from ".TABLE_ADMIN." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkEmailData($data,$id){
		global $db; $error=array();
		if(!strlen(trim($data['commission']))) $error['commission']="Please enter Commission";
		else if(!is_numeric ($data['commission'])) $error['commission']='Please enter valid Commission.<br/>';
		return $error;
	}
	function checkDiscountData($data,$id){
		global $db; $error=array();
		if(!is_numeric ($data['discount'])) $error['discount']='Please enter Numerals Only.<br/>';
		
		return $error;
	}
	
		function updateEmailData($data,$id){
		global $db;
		$update="update ".TABLE_ADMIN." set commission='".mysql_escape_string(stripslashes($data['commission']))."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt) echo "<script>location.replace('index.php?p=commission&msg=2');</script>";
	}	
	function updateDiscountData($data,$id){
		global $db;
		$update="update ".TABLE_ADMIN." set discount='".mysql_escape_string(stripslashes($data['discount']))."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt) echo "<script>location.replace('index.php?p=commission&msg=3');</script>";
	}	
}
?>