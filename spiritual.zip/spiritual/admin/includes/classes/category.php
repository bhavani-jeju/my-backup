<?php
function make_thumb($img_name,$filename,$new_w,$new_h,$ext)
	{
		
		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))
			$src_img=imagecreatefromjpeg($img_name);
		
		if(!strcmp("png",$ext))
			$src_img=imagecreatefrompng($img_name);

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))
			$src_img=imagecreatefromgif($img_name);
	
		//gets the dimmensions of the image
		$old_x=imagesx($src_img);
		$old_y=imagesy($src_img);
		
		
		$thumb_w=$new_w;
		$thumb_h=$new_h;
		
		
		// we create a new image with the new dimmensions
		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);
		
		// resize the big image to the new created one
		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);
		
		// output the created image to the file. Now we will have the thumbnail into the file named by $filename
		if(!strcmp("png",$ext))
			imagepng($dst_img,$filename);
		else
			imagejpeg($dst_img,$filename);
		
		//destroys source and destination images.
		imagedestroy($dst_img);
		imagedestroy($src_img);
	}
class content{

	function getData($id){
		global $db;
		$select="select * from ".TABLE_CATEGORIES." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkData($data,$id){
		global $db; $error="";
		if(!strlen(trim($data['title']))) $error.='Please enter Title.<br />';
		else{
			if($id) $subquery=" and id<>".$id; else $subquery="";
			$select="select id from ".TABLE_CATEGORIES." where title='".mysql_escape_string(stripslashes($data['title']))."' and parent='".mysql_escape_string(stripslashes($data['parent']))."' $subquery";
			$num=$db->fetchNum($select);
			if($num) $error.='Category Title already exists.<br />';
		}
		
		return $error;
	}
	
	function insertData($data){
		global $db;
		$insert="insert into ".TABLE_CATEGORIES." set title='".mysql_escape_string(stripslashes($data['title']))."', parent='".(int)$data['parent']."'";
		$reuslt=$db->fetchResult($insert);
		if($reuslt){
		    if(strlen(trim($_POST['keyword']))){
				$id=mysql_insert_id();
				global $alias;
				$query ='category_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));
				$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}		
		  echo "<script>location.replace('index.php?p=categories&msg=1');</script>";
		}
	}
	
	function updateData($data,$id){
		global $db;
		$update="update ".TABLE_CATEGORIES." set title='".mysql_escape_string(stripslashes($data['title']))."', parent='".(int)$data['parent']."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt){
			if(strlen(trim($_POST['keyword']))){				
				global $alias;
				$query ='category_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);
				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'"))
					$res="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";
				else
					$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}
		 	echo "<script>location.replace('index.php?p=categories&msg=2');</script>";
		}
	}
}
?>