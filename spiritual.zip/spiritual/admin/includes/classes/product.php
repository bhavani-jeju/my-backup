<?php

function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);

					

		if(!strcmp("png",$ext))

			$src_img=imagecreatefrompng($img_name);

			

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		//Ratio 

		$new_width = $thumb_w;

		$new_height = floor( $old_y* ( $thumb_w/ $old_x) );

		

		$thumb_w=$new_width ;

		$thumb_h=$new_height ;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}



class content{

	function getData($id){

		global $db;

		$select="select * from ".TABLE_PRODUCTS." where id=".(int)$id;

		$data=$db->fetchRow($select);

		return $data;

	}

	function checkData($data,$id){

		global $db; $error=array();

		if(!strlen(trim($data['title']))) $error['title']='Please enter Title.<br />';

		else{

			if($id) $subquery=" and id<>".$id; else $subquery="";

			$select="select id from ".TABLE_PRODUCTS." where title='".mysql_escape_string(stripslashes($data['title']))."' and cid='".mysql_escape_string(stripslashes($data['cid']))."' $subquery";

			$num=$db->fetchNum($select);

			if($num) $error['title']='Product Title already exists.<br />';

		}

		if(!strlen(trim($data['cid']))) $error['cid']='Please select Category.<br />';
		if(!strlen(trim($data['status']))) $error['status']='Please select Type.<br />';

			
if($id){

			if(strlen(trim($_FILES['mimg']['name']))){

				$ext=strtolower(substr(strrchr($_FILES['mimg']['name'],'.'),1));

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['img']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}

		else {

		if(!strlen(trim($_FILES['mimg']['name']))) $error['img']='Browse the main image to upload.<br />';

			else{

				$ext=strtolower(substr(strrchr($_FILES['mimg']['name'],'.'),1));

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['img']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}

		return $error;

	}

	function insertData($data){

		global $db;		

	

		for($i=0; $i<sizeof($data['color']); $i++)

		{

			$color.=$data['color'][$i].',';

		}

		rtrim($color,',');
	for($j=0; $j<sizeof($data['size']); $j++)

		{

			$size.=$data['size'][$j].',';

		}

		rtrim($size,',');
                
if($data['ctype']=='admin'){
	$ctype="admin";
}
else
{
	$ctype="merchant";
}
                

				$type="admin";		

		$insert="insert into ".TABLE_PRODUCTS." set title='".mysql_escape_string(stripslashes($data['title']))."',

											    cid='".mysql_escape_string(stripslashes($data['cid']))."',scost='".mysql_escape_string(stripslashes($data['scost']))."',comm='".mysql_escape_string(stripslashes($data['comm']))."',

												mtitle='".mysql_escape_string(stripslashes($data['mtitle']))."',

										  		mkey='".mysql_escape_string(stripslashes($data['mkey']))."',

										 		mdesc='".mysql_escape_string(stripslashes($data['mdesc']))."',

											   edate='".mysql_escape_string(stripslashes(date("Y-m-d",strtotime($data['edate']))))."',mno='".mysql_escape_string(stripslashes($data['mno']))."',

											    price='".mysql_escape_string(stripslashes($data['price']))."',scharge='".mysql_escape_string(stripslashes($data['scharge']))."',type='".mysql_escape_string(stripslashes($ctype))."',email='".mysql_escape_string(stripslashes($data['email']))."',

											   
                                                 status='".mysql_escape_string(stripslashes($data['status']))."',
                                               

												

												featured='".mysql_escape_string(stripslashes($data['featured']))."',

											    content='".mysql_escape_string(stripslashes($data['content']))."',sterms='".mysql_escape_string(stripslashes($data['sterms']))."',mvedio='".mysql_escape_string(stripslashes($data['mvedio']))."'";

										

		$reuslt=$db->fetchResult($insert);

		$id = mysql_insert_id();

		

		if(strlen(trim($_POST['keyword']))){

			global $alias;

			$query ='product_id='.$id;

			$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));

			$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";

			$row=$db->fetchResult($res);
			if($row){
				$query ='vedio_id='.$id;

			$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));

			$res1="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
$db->fetchResult($res1);
			}

		}

		

		$mimg=$_FILES['mimg']['name'];

		$ext=strtolower(substr(strrchr($mimg,'.'),1));

				

		$img1="../images/products/img".$id.".".$ext;
		$img2="../images/products/img".$id.".".$ext;

		if(move_uploaded_file($_FILES['mimg']['tmp_name'], $img1))

		{			

			$thumb=make_thumb($img1,$img2,202,305,$ext);

			$thumb=make_thumb($img1,$img3,202,305,$ext);

			$thumb=make_thumb($img1,$img4,202,305,$ext);

		}

		

		$mainimage=$id.'.'.$ext;

		

		$update="update ".TABLE_PRODUCTS." set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

		$reuslt=$db->fetchResult($update);

		

		for($i=1;$i<=4;$i++){		

			if(strlen(trim($_FILES['simg'.$i]['name']))){

				$simg = $_FILES['simg'.$i]['name'];

				$ext=strtolower(substr(strrchr($simg,'.'),1));

				$img1='../images/products/imga'.$id.'-'.$i.'.'.$ext;

				$img2="../images/products/imgb".$id.'-'.$i.'.'.$ext;

				$img3="../images/products/imgc".$id.'-'.$i.'.'.$ext;

				$img4="../images/products/imgd".$id.'-'.$i.'.'.$ext;

				

				$subimg=$id.'-'.$i.'.'.$ext;

				if(move_uploaded_file($_FILES['simg'.$i]['tmp_name'],$img1)){					

					$thumb=make_thumb($img1,$img2,120,150,$ext);

					$thumb=make_thumb($img1,$img3,50,75,$ext);

					$thumb=make_thumb($img1,$img4,50,50,$ext);

				}					

				$subimg=$id.'-'.$i.'.'.$ext;

				$subimage='subimage'.$i;

				$update="update ".TABLE_PRODUCTS." set $subimage = '".mysql_escape_string(stripslashes($subimg))."' where id=".$id;

				$reuslt=$db->fetchResult($update);

			}

		}		

		

		if($reuslt)  echo "<script>location.replace('index.php?p=products&msg=1');</script>";	

	

	}

	

	function updateData($data,$id){

		global $db;		

		

		$mimg=$_FILES['mimg']['name'];

		$ext=strtolower(substr(strrchr($mimg,'.'),1));

			

		$img1="../images/products/img".$id.".".$ext;

		$img2="../images/products/img".$id.".".$ext;

		if(move_uploaded_file($_FILES['mimg']['tmp_name'],$img1)){

			$thumb=make_thumb($img1,$img2,202,305,$ext);

		}

         $select_img="select id,image from ".TABLE_PRODUCTS." where id='".$id."' ";

			$num_img=$db->fetchRow($select_img);

			$mainimage=$id.'.'.$ext;

			if(!empty($_FILES['mimg']['name'])){

				 $update="update ".TABLE_PRODUCTS." set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

				 $db->fetchResult($update);	

			}

		                        

$a=1;	
if($data['ctype']=='admin'){
	$ctype="admin";
}
else
{
	$ctype="merchant";
}	

			$update="update ".TABLE_PRODUCTS." set title='".mysql_escape_string(stripslashes($data['title']))."',

											    cid='".mysql_escape_string(stripslashes($data['cid']))."',scost='".mysql_escape_string(stripslashes($data['scost']))."',comm='".mysql_escape_string(stripslashes($data['comm']))."',

												mtitle='".mysql_escape_string(stripslashes($data['mtitle']))."',

										  		mkey='".mysql_escape_string(stripslashes($data['mkey']))."',

										 		mdesc='".mysql_escape_string(stripslashes($data['mdesc']))."',

											   edate='".mysql_escape_string(stripslashes(date("Y-m-d",strtotime($data['edate']))))."',mno='".mysql_escape_string(stripslashes($data['mno']))."',type='".mysql_escape_string(stripslashes($ctype))."',email='".mysql_escape_string(stripslashes($data['email']))."',

											    price='".mysql_escape_string(stripslashes($data['price']))."',scharge='".mysql_escape_string(stripslashes($data['scharge']))."',

											   
                                                 status='".mysql_escape_string(stripslashes($data['status']))."',
                                               

												

												featured='".$a."',

											    content='".mysql_escape_string(stripslashes($data['content']))."',sterms='".mysql_escape_string(stripslashes($data['sterms']))."',mvedio='".mysql_escape_string(stripslashes($data['mvedio']))."'

												where id=".$id;	

										  												

		$reuslt=$db->fetchResult($update);

		if($reuslt){

			if(strlen(trim($_POST['keyword']))){				

				global $alias;

				$query ='product_id='.$id;

				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);

				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'"))

					$res="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";

				else

					$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";

				$row=$db->fetchResult($res);
			if($row){
					$query ='vedio_id='.$id;

				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);

				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'")){


					$res1="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";
				}
				else{
				
echo $keyword;
					 $res1="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				}

				$db->fetchResult($res1);
			}

			}

						

			for($i=1;$i<=4;$i++){		

				if(strlen(trim($_FILES['simg'.$i]['name']))){

					$simg = $_FILES['simg'.$i]['name'];

					$ext=strtolower(substr(strrchr($simg,'.'),1));

					$img1='../images/products/imga'.$id.'-'.$i.'.'.$ext;

					$img2="../images/products/imgb".$id.'-'.$i.'.'.$ext;

					$img3="../images/products/imgc".$id.'-'.$i.'.'.$ext;

					$img4="../images/products/imgd".$id.'-'.$i.'.'.$ext;

					

					$subimg=$id.'-'.$i.'.'.$ext;

					if(move_uploaded_file($_FILES['simg'.$i]['tmp_name'],$img1)){					

						$thumb=make_thumb($img1,$img2,50,75,$ext);

						$thumb=make_thumb($img1,$img3,120,150,$ext);

						$thumb=make_thumb($img1,$img4,50,50,$ext);

					}					

					$subimg=$id.'-'.$i.'.'.$ext;

					$subimage='subimage'.$i;

					$update="update ".TABLE_PRODUCTS." set $subimage = '".mysql_escape_string(stripslashes($subimg))."' where id=".$id;

					$reuslt=$db->fetchResult($update);

				}

			}

			

		 echo "<script>location.replace('index.php?p=products&msg=2');</script>";

		 }

	}

}

?>