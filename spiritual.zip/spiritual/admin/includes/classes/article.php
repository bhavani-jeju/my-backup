<?php

function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);

					

		if(!strcmp("png",$ext))

			$src_img=imagecreatefrompng($img_name);

			

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		//Ratio 

		//$new_width = $thumb_w;

		//$new_height = floor( $old_y* ( $thumb_w/ $old_x) );

		

		//$thumb_w=$new_width ;

		//$thumb_h=$new_height ;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}
class content{

	function getData($id){
		global $db;
		$select="select * from articles where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkData($data,$id){
		global $db; $error="";
		if(!strlen(trim($data['title']))) $error.='Please enter Title.<br />';
		if(!strlen(trim($data['user']))) $error.='Please enter User.<br />';
		if(!strlen(trim($data['links']))) $error.='Please enter Links.<br />';
		else{
			if($id) $subquery=" and id<>".$id; else $subquery="";
			$select="select id from articles where title='".mysql_escape_string(stripslashes($data['title']))."' $subquery";
			$num=$db->fetchNum($select);
			if($num) $error.='Article Title already exists.<br />';
			if($id){

			if(strlen(trim($_FILES['bimage']['name']))){

				$ext=strtolower(substr(strrchr($_FILES['bimage']['name'],'.'),1));

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['mimage']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}

		else {

		if(!strlen(trim($_FILES['bimage']['name']))) $error['bimage']='Browse the main image to upload.<br />';

			else{

				$ext=strtolower(substr(strrchr($_FILES['bimage']['name'],'.'),1));

				if($ext!='jpg' && $ext!='jpeg' && $ext!='png' && $ext!='gif') $error['bimage']='Please upload only jpg,jpeg,png and gif images.<br />';

			}

		}
		}
		
		return $error;
	}
	
	function insertData($data){
		global $db;
		$date=date('Y-m-d');  
				$insert="insert into articles set title='".mysql_escape_string(stripslashes($data['title']))."',links='".mysql_escape_string(stripslashes($data['links']))."',description='".mysql_escape_string(stripslashes($data['description']))."',user='".mysql_escape_string(stripslashes($data['user']))."',date='".$date."'";
		$reuslt=$db->fetchResult($insert);
		$id = mysql_insert_id();
		if($reuslt){
		    if(strlen(trim($_POST['keyword']))){
				$id=mysql_insert_id();
				global $alias;
				$query ='brand_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));
				$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}
			
		$mimg=$_FILES['bimage']['name'];
		$ext=substr(strrchr($mimg,'.'),1);
		$img1="../images/articles/img".$id.".".$ext;
		move_uploaded_file($_FILES['bimage']['tmp_name'], $img1);
		$mainimage=$id.'.'.$ext;
		
				$update="update articles set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;
		
		$reuslt=$db->fetchResult($update);
		if($reuslt)
		  echo "<script>location.replace('index.php?p=articles&msg=1');</script>";
		}
		}
	
	
	function updateData($data,$id){
		global $db;
		if(strlen(trim($_FILES['bimage']['name']))){
	
	//IMAGE NAME WILL BE STORED IN $image VARIABLE
	$image = $_FILES['bimage']['name'];
	
	//MOVE THE IMAGE FROM THE TEMPORARY LOCATION TO OR WEBSITE 'IMAGES' FOLDER
	move_uploaded_file($_FILES['bimage']['tmp_name'],"../images/articles/img".$image);
	}
	else
	$image='';
	
	
	$id=$_GET['id'];
			$q1=mysql_query("select * from articles where id='$id'"); 
	$row1=mysql_fetch_array($q1);
	
	if($image==""){
	$org=$row1[image];
	}
	else{
	$org=$image;
	
	}
			mysql_query("update  articles set image='".mysql_escape_string(stripslashes($org))."' where id='$id'" ) or die(mysql_error());
$date=date('Y-m-d');
		$update="update articles set title='".mysql_escape_string(stripslashes($data['title']))."' ,links='".mysql_escape_string(stripslashes($data['links']))."',description='".mysql_escape_string(stripslashes($data['description']))."',user='".mysql_escape_string(stripslashes($data['user']))."',date='".$date."'   where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt){
			if(strlen(trim($_POST['keyword']))){				
				global $alias;
				$query ='brand_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);
				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'"))
					$res="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";
				else
					$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}
		 	echo "<script>location.replace('index.php?p=articles&msg=2');</script>";
		}
	}
}
?>