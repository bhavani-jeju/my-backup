<?php
class content{
	function getData($id){
		global $db;
		$select="select * from ".TABLE_CONTENT." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	function updateData($data,$id){
		global $db;
		$update="update ".TABLE_CONTENT." set mtitle='".mysql_escape_string(stripslashes($data['mtitle']))."',
										      mkey='".mysql_escape_string(stripslashes($data['mkey']))."',
										      mdesc='".mysql_escape_string(stripslashes($data['mdesc']))."'
										      where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt) echo "<script>location.replace('index.php?p=seo&msg=2');</script>";
	}
}
?>