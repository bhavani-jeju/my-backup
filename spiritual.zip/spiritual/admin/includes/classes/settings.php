<?php

class content{

	function getData($id){

		global $db;

		$select="select email from ".TABLE_ADMIN." where id=".(int)$id;

		$data=$db->fetchRow($select);

		return $data;

	}

	

	function checkPassData($data,$id){

		global $db; $error=array();

		if(!strlen(trim($data['pass']))) $error['pass']='Please enter Password';

		if(!strlen(trim($data['repass']))) $error['repass']='Please enter Confirm Password';

		else if($data['repass']<>$data['pass']) $error['repass']='Passwords does not match';

		return $error;

	}

	function checkEmailData($data,$id){

		global $db; $error=array();

		if(!strlen(trim($data['email']))) $error['email']="Please enter Email Address";

		//else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$",$data['email'])) $error['email']="Please enter valid Email Address";

		return $error;

	}

	

	function updatePassData($data,$id){

		global $db;

		$update="update ".TABLE_ADMIN." set password='".mysql_escape_string(stripslashes($data['pass']))."' where id=".$id;

		$reuslt=$db->fetchResult($update);

		if($reuslt) echo "<script>location.replace('index.php?p=settings&msg=1');</script>";

	}

	function updateEmailData($data,$id){

		global $db;

		$update="update ".TABLE_ADMIN." set email='".mysql_escape_string(stripslashes($data['email']))."' where id=".$id;

		$reuslt=$db->fetchResult($update);

		if($reuslt) echo "<script>location.replace('index.php?p=settings&msg=2');</script>";

	}	

}

?>