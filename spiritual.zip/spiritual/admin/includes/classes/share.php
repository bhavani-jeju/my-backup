<?php
class content{
	function getData($id){
		global $db;
		$select="select facebook,twitter,youtube,gplus,linkedin,rssfeed from ".TABLE_ADMIN." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function updateData($data,$id){
		global $db;
		$update="update ".TABLE_ADMIN." set facebook='".mysql_escape_string($data['facebook'])."', twitter='".mysql_escape_string($data['twitter'])."', youtube='".mysql_escape_string($data['youtube'])."', gplus='".mysql_escape_string($data['gplus'])."', linkedin='".mysql_escape_string($data['linkedin'])."', rssfeed='".mysql_escape_string($data['rssfeed'])."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt) echo "<script>location.replace('index.php?p=share&msg=1');</script>";
	}	
}
?>