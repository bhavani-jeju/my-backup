<?php

function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);

					

		if(!strcmp("png",$ext))

			$src_img=imagecreatefrompng($img_name);

			

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}



class content{

	function getData($id){

		global $db;

		$select="select * from ".TABLE_BANNERS." where id=".(int)$id;

		$data=$db->fetchRow($select);

		return $data;

	}

	function checkData($data,$id){

		global $db; $error=array();

		if(!strlen(trim($data['title']))) $error['title']='Please enter Title.<br />';		

		if($id){


		if(!strlen(trim($_FILES['mimg']['name']))) $error['img']='Browse the main vedio to upload.<br />';

			

		}

		return $error;

	}

	function insertData($data){

		global $db;		

						

		$insert="insert into ".TABLE_BANNERS." set title='".mysql_escape_string(stripslashes($data['title']))."', content='".mysql_escape_string(stripslashes($data['content']))."'";

										

		$reuslt=$db->fetchResult($insert);

		$id = mysql_insert_id();

		

		$mimg=$_FILES['mimg']['name'];

		$ext=substr(strrchr($mimg,'.'),1);

				

		$img1="../images/vedios/file".$id.".".$ext;

		 

		if(move_uploaded_file($_FILES['mimg']['tmp_name'], $img1))

		{			

			
		}

		

		$mainimage=$id.'.'.$ext;

		

		$update="update ".TABLE_BANNERS." set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

		$reuslt=$db->fetchResult($update);

		

		if($reuslt)  echo "<script>location.replace('index.php?p=banners&msg=1');</script>";	

	

	}

	

	function updateData($data,$id){

		global $db;		

		

		$mimg=$_FILES['mimg']['name'];

		$ext=substr(strrchr($mimg,'.'),1);

			

		$img1="../images/vedios/file".$id.".".$ext;

		$mainimage=$id.'.'.$ext;

		if(move_uploaded_file($_FILES['mimg']['tmp_name'],$img1)){

			
			$update="update ".TABLE_BANNERS." set image='".mysql_escape_string(stripslashes($mainimage))."' where id=".$id;

			$db->fetchResult($update);	

		}

        					

		$update="update ".TABLE_BANNERS." set title='".mysql_escape_string(stripslashes($data['title']))."', content='".mysql_escape_string(stripslashes($data['content']))."' where id=".$id;				  

																					

		$reuslt=$db->fetchResult($update);

		if($reuslt){

			echo "<script>location.replace('index.php?p=banners&msg=2');</script>";

		 }

	}

}

?>