<?php
class content{	
	function getExpressData($id){
		global $db;
		$select="select paypal,api_username,api_password,api_signature,supplier_email from ".TABLE_ADMIN." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}	
	function checkExpressData($data,$id){
		global $db; $error=array();
		if(!strlen(trim($data['paypal']))) $error['paypal']='Please enter Email Address';	
		else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$",$data['paypal'])) $error['paypal']="Please enter valid Email Address";
		if(!strlen(trim($data['supplier_email']))) $error['supplier_email']='Please enter Supplier Email Address';	
		else if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$",$data['supplier_email'])) $error['supplier_email']="Please enter valid Supplier Email Address";
		if(!strlen(trim($data['api_username']))) $error['api_username']='Please enter Api Username';
		if(!strlen(trim($data['api_password']))) $error['api_password']='Please enter Api Password';
		if(!strlen(trim($data['api_signature']))) $error['api_signature']='Please enter Api Signature';		
		return $error;
	}
	
	function updateExpressData($data,$id){
		global $db;
		$update="update ".TABLE_ADMIN." set paypal='".mysql_escape_string(stripslashes($data['paypal']))."',
											supplier_email='".mysql_escape_string(stripslashes($data['supplier_email']))."',
											api_username='".mysql_escape_string(stripslashes($data['api_username']))."',
											api_password='".mysql_escape_string(stripslashes($data['api_password']))."',
											api_signature='".mysql_escape_string(stripslashes($data['api_signature']))."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt) echo "<script>location.replace('index.php?p=pgs&msg=2');</script>";
	}
	
}
?>