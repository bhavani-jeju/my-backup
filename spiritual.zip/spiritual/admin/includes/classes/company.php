<?php
class content{

	function getData($id){
		global $db;
		$select="select * from company where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkData($data,$id){
		global $db; $error="";
		if(!strlen(trim($data['title']))) $error.='Please enter Title.<br />';
		else{
			if($id) $subquery=" and id<>".$id; else $subquery="";
			$select="select id from company where title='".mysql_escape_string(stripslashes($data['title']))."'  $subquery";
			$num=$db->fetchNum($select);
			if($num) $error.='company Title already exists.<br />';
		}
		
		return $error;
	}
	
	function insertData($data){
		global $db;
		$insert="insert into company set title='".mysql_escape_string(stripslashes($data['title']))."'";
		$reuslt=$db->fetchResult($insert);
		if($reuslt){
		    if(strlen(trim($_POST['keyword']))){
				$id=mysql_insert_id();
				global $alias;
				$query ='company_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))));
				$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}		
		  echo "<script>location.replace('index.php?p=companys&msg=1');</script>";
		}
	}
	
	function updateData($data,$id){
		global $db;
		$update="update company set title='".mysql_escape_string(stripslashes($data['title']))."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt){
			if(strlen(trim($_POST['keyword']))){				
				global $alias;
				$query ='company_id='.$id;
				$keyword = $alias->get_alias(str_replace(" ","-",strip_tags(strtolower($_POST['keyword']))),0,$query);
				if($db->fetchNum("select id from ".TABLE_ALIAS." where query='".$query."'"))
					$res="update ".TABLE_ALIAS." set keyword='".mysql_escape_string(stripslashes($keyword))."' where query='".mysql_escape_string(stripslashes($query))."'";
				else
					$res="insert into ".TABLE_ALIAS." set query='".mysql_escape_string(stripslashes($query))."',keyword='".mysql_escape_string(stripslashes($keyword))."'";
				$db->fetchResult($res);
			}
		 	echo "<script>location.replace('index.php?p=companys&msg=2');</script>";
		}
	}
}
?>