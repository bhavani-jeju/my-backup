<?php
class content{

	function getData($id){
		global $db;
		$select="select * from ".TABLE_TESTIMONIALS." where id=".(int)$id;
		$data=$db->fetchRow($select);
		return $data;
	}
	
	function checkData($data,$id){
		global $db; $error=array();
		if(!strlen(trim($data['clientname']))) $error['clientname']='Please enter Client Name.<br />';
		else{
			if($id) $subquery=" and id<>".$id; else $subquery="";
			$select="select id from ".TABLE_TESTIMONIALS." where clientname='".mysql_escape_string(stripslashes($data['clientname']))."' $subquery";
			$num=$db->fetchNum($select);
			if($num) $error['clientname']='Client Name already exists.<br />';
		}
		if(!strlen(trim($data['testimonial']))) $error['testimonial']='Please enter Testimonial.<br />';
		
		return $error;
	}
	
	function insertData($data){
		global $db;
		$insert="insert into ".TABLE_TESTIMONIALS." set clientname='".mysql_escape_string(stripslashes($data['clientname']))."', testimonial='".mysql_escape_string(stripslashes($data['testimonial']))."'";
		$reuslt=$db->fetchResult($insert);
		if($reuslt){		    		
			echo "<script>location.replace('index.php?p=testimonials&msg=1');</script>";
		}
	}
	
	function updateData($data,$id){
		global $db;
		$update="update ".TABLE_TESTIMONIALS." set clientname='".mysql_escape_string(stripslashes($data['clientname']))."', testimonial='".mysql_escape_string(stripslashes($data['testimonial']))."' where id=".$id;
		$reuslt=$db->fetchResult($update);
		if($reuslt){		  
		 	echo "<script>location.replace('index.php?p=testimonials&msg=2');</script>";
		}
	}
}
?>