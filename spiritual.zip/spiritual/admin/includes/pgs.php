<?php
include("includes/classes/pgs.php");
$obj_content=new content();
if(!isset($_POST['btn_express_submit'])){
	$data=$obj_content->getExpressData(1);
	$_POST['paypal']=$data['paypal'];
	$_POST['supplier_email']=$data['supplier_email'];
	$_POST['api_username']=$data['api_username'];
	$_POST['api_password']=$data['api_password'];
	$_POST['api_signature']=$data['api_signature'];
}

if(isset($_POST['btn_express_submit'])){
	$error=array();
	$error=$obj_content->checkExpressData($_POST,1);
	if(count($error)==0){
			$obj_content->updateExpressData($_POST,1);		
	}
}
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=pgs">Payment Gateways</a>
		</li>
	</ul>
</div>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<?php if($_GET['msg']==2){?>PayPal Parallel Payment details updated successfully.<?php } ?>
	</div>
<?php } ?> 
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-edit"></i>Payment Gateways</h2>
		</div>
		<div class="box-content">
			<form id="edit" class="form-horizontal" name="frm" action="" method="post">
				<fieldset>
                	<legend>Paypal Parallel Payments</legend>
                	<div class="control-group <?php if(strlen(trim($error['paypal']))) echo 'error';?>">
					  <label class="control-label">PayPal Email Address</label>
					  <div class="controls">
						<input type="text" name="paypal" class="input-xlarge focused" value="<?php if(isset($_POST['paypal'])) echo $_POST['paypal'];?>">
						<?php if(strlen(trim($error['paypal']))){?><span class="help-inline"><?php echo $error['paypal'];?></span><?php } ?>
					  </div>
					</div>	
                    <div class="control-group <?php if(strlen(trim($error['supplier_email']))) echo 'error';?>">
					  <label class="control-label">Supplier PayPal Email Address</label>
					  <div class="controls">
						<input type="text" name="supplier_email" class="input-xlarge focused" value="<?php if(isset($_POST['supplier_email'])) echo $_POST['supplier_email'];?>">
						<?php if(strlen(trim($error['supplier_email']))){?><span class="help-inline"><?php echo $error['supplier_email'];?></span><?php } ?>
					  </div>
					</div>		
					
					<div class="control-group <?php if(strlen(trim($error['api_username']))) echo 'error';?>">
					  <label class="control-label">Api Username</label>
					  <div class="controls">
						<input type="text" name="api_username" class="input-xlarge focused" value="<?php if(isset($_POST['api_username'])) echo $_POST['api_username'];?>">
						<?php if(strlen(trim($error['api_username']))){?><span class="help-inline"><?php echo $error['api_username'];?></span><?php } ?>
					  </div>
					</div>	
					<div class="control-group <?php if(strlen(trim($error['api_password']))) echo 'error';?>">
					  <label class="control-label">Api Password</label>
					  <div class="controls">
						<input type="text" name="api_password" class="input-xlarge focused" value="<?php if(isset($_POST['api_password'])) echo $_POST['api_password'];?>">
						<?php if(strlen(trim($error['api_password']))){?><span class="help-inline"><?php echo $error['api_password'];?></span><?php } ?>
					  </div>
					</div>
					<div class="control-group <?php if(strlen(trim($error['api_signature']))) echo 'error';?>">
					  <label class="control-label">Api Signature</label>
					  <div class="controls">
						<input type="text" name="api_signature" class="input-xlarge focused" value="<?php if(isset($_POST['api_signature'])) echo $_POST['api_signature'];?>">
						<?php if(strlen(trim($error['api_signature']))){?><span class="help-inline"><?php echo $error['api_signature'];?></span><?php } ?>
					  </div>
					</div>
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_express_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>					
				</fieldset>
			</form>			
		</div>
	</div><!--/span-->
</div><!--/row-->