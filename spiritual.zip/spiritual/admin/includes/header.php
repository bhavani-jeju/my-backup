<!DOCTYPE html>

<html lang="en">

<head>

	<!--

		Charisma v1.0.0



		Copyright 2012 Muhammad Usman

		Licensed under the Apache License v2.0

		http://www.apache.org/licenses/LICENSE-2.0



		http://usman.it

		http://twitter.com/halalit_usman

	-->

	<meta charset="utf-8">

	<title><?php echo SITE_NAME;?> Admin Panel</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta name="description" content="A fully featured, responsive, HTML5, Bootstrap Prominere admin template.">

	<meta name="author" content="Prominere">



	<!-- The styles -->

	<link id="bs-css" href="css/bootstrap-cerulean.css" rel="stylesheet">

	<style type="text/css">

	  body {

		padding-bottom: 40px;

	  }

	  .sidebar-nav {

		padding: 9px 0;

	  }

	</style>

	<link href="css/bootstrap-responsive.css" rel="stylesheet">

	<link href="css/style.css" rel="stylesheet">

	<link href="css/jquery-ui-1.8.21.custom.css" rel="stylesheet">

	<link href='css/fullcalendar.css' rel='stylesheet'>

	<link href='css/fullcalendar.print.css' rel='stylesheet'  media='print'>

	<link href='css/chosen.css' rel='stylesheet'>

	<link href='css/uniform.default.css' rel='stylesheet'>

	<link href='css/colorbox.css' rel='stylesheet'>

	<link href='css/jquery.cleditor.css' rel='stylesheet'>

	<link href='css/jquery.noty.css' rel='stylesheet'>

	<link href='css/noty_theme_default.css' rel='stylesheet'>

	<link href='css/elfinder.min.css' rel='stylesheet'>

	<link href='css/elfinder.theme.css' rel='stylesheet'>

	<link href='css/jquery.iphone.toggle.css' rel='stylesheet'>

	<link href='css/opa-icons.css' rel='stylesheet'>

	<link href='css/uploadify.css' rel='stylesheet'>



	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->

	<!--[if lt IE 9]>

	  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>

	<![endif]-->



	<!-- The fav icon -->

	<link rel="shortcut icon" href="img/favicon.ico">

		

</head>



<body>

	<?php if(!isset($no_visible_elements) || !$no_visible_elements)	{ ?>

	<!-- topbar starts -->

	<div class="navbar">

		<div class="navbar-inner">

			<div class="container-fluid">

				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

					<span class="icon-bar"></span>

				</a>

				<a class="brand" href="index.php"><span><?php echo SITE_NAME;?></span></a>

				

				<!-- theme selector starts -->

				<div class="btn-group pull-right theme-container" >

					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">

						<i class="icon-tint"></i><span class="hidden-phone"> Change Theme / Skin</span>

						<span class="caret"></span>

					</a>

					<ul class="dropdown-menu" id="themes">

						<li><a data-value="classic" href="#"><i class="icon-blank"></i> Classic</a></li>

						<li><a data-value="cerulean" href="#"><i class="icon-blank"></i> Cerulean</a></li>

						<li><a data-value="cyborg" href="#"><i class="icon-blank"></i> Cyborg</a></li>

						<li><a data-value="redy" href="#"><i class="icon-blank"></i> Redy</a></li>

						<li><a data-value="journal" href="#"><i class="icon-blank"></i> Journal</a></li>

						<li><a data-value="simplex" href="#"><i class="icon-blank"></i> Simplex</a></li>

						<li><a data-value="slate" href="#"><i class="icon-blank"></i> Slate</a></li>

						<li><a data-value="spacelab" href="#"><i class="icon-blank"></i> Spacelab</a></li>

						<li><a data-value="united" href="#"><i class="icon-blank"></i> United</a></li>

					</ul>

				</div>

				<!-- theme selector ends -->

				

				<!-- user dropdown starts -->

				<div class="btn-group pull-right" >

					<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">

						<i class="icon-user"></i><span class="hidden-phone"> admin</span>

						<span class="caret"></span>

					</a>

					<ul class="dropdown-menu">

						<li><a href="index.php?p=settings">Profile</a></li>

						<li class="divider"></li>

						<li><a href="logout.php">Logout</a></li>

					</ul>

				</div>

				<!-- user dropdown ends -->

				

				<div class="top-nav nav-collapse">

					<ul class="nav">

						<li><a href="../" target="_blank">Visit Site</a></li>						

					</ul>

				</div><!--/.nav-collapse -->

			</div>

		</div>

	</div>

	<!-- topbar ends -->

	<?php } ?>

	<div class="container-fluid">

		<div class="row-fluid">

		<?php if(!isset($no_visible_elements) || !$no_visible_elements) { ?>

		

			<!-- left menu starts -->

			<div class="span2 main-menu-span">

				<div class="well nav-collapse sidebar-nav">

					<ul class="nav nav-tabs nav-stacked main-menu">

						<li class="nav-header hidden-tablet">Main</li>

						
						<li><a class="ajax-link" href="index.php?p=categories"><i class="icon-list-alt"></i><span class="hidden-tablet"> Categories</span></a></li>
                         
						<li><a class="ajax-link" href="index.php?p=pgs"><i class="icon-list-alt"></i><span class="hidden-tablet"> Payment Gateways</span></a></li>

						<li><a class="ajax-link" href="index.php?p=hsettings"><i class="icon-align-justify"></i><span class="hidden-tablet"> Settings</span></a></li>

						<!--<li><a class="ajax-link" href="index.php?p=coupons"><i class="icon-align-justify"></i><span class="hidden-tablet"> Coupons</span></a></li>-->

						
                        <li><a class="ajax-link" href="index.php?p=articles"><i class="icon-calendar"></i><span class="hidden-tablet"> Articles</span></a></li>

                       
						<li><a class="ajax-link" href="index.php?p=banners"><i class="icon-picture"></i><span class="hidden-tablet"> Banners</span></a></li>	
						<li><a class="ajax-link" href="index.php?p=users"><i class="icon-th"></i><span class="hidden-tablet"> Users</span></a></li>
                        

						<li><a class="ajax-link" href="index.php?p=contents"><i class="icon-align-justify"></i><span class="hidden-tablet"> Pages</span></a></li>
                        

                        <li><a class="ajax-link" href="index.php?p=seo"><i class="icon-globe"></i><span class="hidden-tablet"> SEO Settings</span></a></li>						

						<li><a class="ajax-link" href="index.php?p=testimonials"><i class="icon-globe"></i><span class="hidden-tablet"> Testimonials</span></a></li>
                        <li><a class="ajax-link" href="index.php?p=commission"><i class="icon-globe"></i><span class="hidden-tablet"> PricE Manipulations</span></a></li>							
					

                        <li><a class="ajax-link" href="index.php?p=share"><i class="icon-share"></i><span class="hidden-tablet"> Share Icons</span></a></li>
 <li><a class="ajax-link" href="index.php?p=newsletter"><i class="icon-share"></i><span class="hidden-tablet">Newsletter</span></a></li>
                        
						<li><a class="ajax-link" href="logout.php"><i class="icon-cog"></i><span class="hidden-tablet"> Logout</span></a></li>

					</ul>

					<label id="for-is-ajax" class="hidden-tablet" for="is-ajax"><input id="is-ajax" type="checkbox"> Ajax on menu</label>

				</div><!--/.well -->

			</div><!--/span-->

			<!-- left menu ends -->

			

			<noscript>

				<div class="alert alert-block span10">

					<h4 class="alert-heading">Warning!</h4>

					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>

				</div>

			</noscript>

			

			<div id="content" class="span10">

			<!-- content starts -->

			<?php } ?>

