

<?php
function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);

					

		if(!strcmp("png",$ext))

			$src_img=imagecreatefrompng($img_name);

			

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}
if(isset($_POST['btn_submit'])){

	  	  $q1=mysql_query("select * from information") or die(mysql_error());
	  $r2=mysql_fetch_array($q1);
$id=$r2['id'];

					$logo=$_FILES['logo']['name'];
					
			$ext=strtolower(substr(strrchr($logo,'.'),1));
			

	
		$logo1="../images/logo".$id.".".$ext;
		

		
		if(move_uploaded_file($_FILES['logo']['tmp_name'],$logo1)){

	
			//$thumb=make_thumb($img1,$img1,998,380,$ext);
			$mainimage=$id.'.'.$ext;
			
			
			
			
				$update="update information set logo='".mysql_escape_string(stripslashes($mainimage))."' where id=".(int)$id;

			$result1=mysql_query($update)or die(mysql_error());
			if($reuslt1){
			echo "<script>location.replace('index.php?p=hsettings&msg=1');</script>";}
			
		
		}
			

			
}
//simage1
if(isset($_POST['btn_submit1'])){
		$q1=mysql_query("select * from information") or die(mysql_error());
	  $r2=mysql_fetch_array($q1);
$id=$r2['id'];

					
					$simage1=$_FILES['simage1']['name'];
					
			
			$ext1=strtolower(substr(strrchr($simage1,'.'),1));
			

	
		
		$simage1="../images/simage1".$id.".".$ext1;
		

		
		
if(move_uploaded_file($_FILES['simage1']['tmp_name'],$simage1)){
	
	
			//$thumb=make_thumb($img1,$img1,998,380,$ext);
			
			$simage1=$id.'.'.$ext1;
			
			
				$update="update information set simage1='".mysql_escape_string(stripslashes($simage1))."' where id=".(int)$id;

			$result1=mysql_query($update)or die(mysql_error());
			if($reuslt1){
				

			echo "<script>location.replace('index.php?p=hsettings&msg=2');</script>";}
		
		}
			

}
//simage2
if(isset($_POST['btn_submit2'])){
		$q1=mysql_query("select * from information") or die(mysql_error());
	  $r2=mysql_fetch_array($q1);
$id=$r2['id'];

					
					$simage2=$_FILES['simage2']['name'];
					
			
			$ext2=strtolower(substr(strrchr($simage2,'.'),1));
			

	
		
		$simage2="../images/simage2".$id.".".$ext1;
		

		
		
if(move_uploaded_file($_FILES['simage2']['tmp_name'],$simage2)){
	
	
			//$thumb=make_thumb($img1,$img1,998,380,$ext);
			
			$simage2=$id.'.'.$ext2;
			
			
				$update="update information set simage2='".mysql_escape_string(stripslashes($simage2))."' where id=".(int)$id;

			$result2=mysql_query($update)or die(mysql_error());
			if($reuslt2){
				

			echo "<script>location.replace('index.php?p=hsettings&msg=3');</script>";}
			
		
		}
			

}

?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=hsettings">Settings</a>
		</li>
	</ul>
</div>
<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
	<div class="alert alert-success">
		<button type="button" class="close" _POST-dismiss="alert">×</button>
		<?php if($_GET['msg']==1){?>Logo Icons updated successfully.<?php }  else if($_GET['msg']==2){?>Side Icon1 inserted successfully.<?php } else if($_GET['msg']==2){?>Side Icon2 inserted successfully.<?php }?>
	</div>
<?php } ?>
<?php 
$q=mysql_query("select * from information") or die(mysql_error());
$r=mysql_fetch_array($q);
?> 
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" _POST-original-title>
			<h2><i class="icon-edit"></i>Settings</h2>
		</div>
        <div class="box-content"> 			 
			<form id="edit" class="form-horizontal"  enctype="multipart/form-data" name="frm" action="" method="post">
					
                    <div class="control-group">
					  <label class="control-label">Logo</label>
                     
					  <div class="controls">
						<input type="file" name="logo" value="<?php echo $_POST['logo'];?>"/>
                        <img src="../images/logo<?php echo $r['logo'];?>" />
                        
					  </div>
					     </div> 
                         <div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>
                    </form>
                    <form id="edit" class="form-horizontal"  enctype="multipart/form-data" name="frm1" action="" method="post">	              					
					
                    <div class="control-group">
					  <label class="control-label">Side Image1</label>
                     
					  <div class="controls">
						<input type="file" name="simage1" value="<?php echo $_POST['simage1'];?>"/>
                        <img src="../images/simage1<?php echo $r['simage1'];?>" />
                        
					  </div>
					     </div> 
                         <div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit1" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>	
                    </form>
                    <?php /*?><form id="edit" class="form-horizontal"  enctype="multipart/form-data" name="frm2" action="" method="post">
                         <div class="control-group">
					  <label class="control-label">Side Image2</label>
                     
					  <div class="controls">
						<input type="file" name="simage2" value="<?php echo $_POST['simage2'];?>"/>
                        <img src="../images/simage2<?php echo $r['simage2'];?>" />
                        
					  </div>
					     </div> 
                                       					
					<div class="control-group">
						<div class="controls">
							<button type="submit" name="btn_submit2" value="submit" class="btn btn-primary">Save changes</button>
						</div>
					</div>	
                    				
				
			</form><?php */?>
            
          		</div>
	</div><!--/span-->
</div><!--/row-->