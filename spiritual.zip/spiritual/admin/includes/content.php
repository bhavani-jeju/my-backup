<?php

include("includes/classes/content.php");

$obj_content=new content();

if(isset($_GET['id']) && !isset($_POST['btn_submit'])){

	$_POST=$obj_content->getData((int)$_GET['id']);

}

if(isset($_POST['btn_submit'])){

	$error="";

	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";

	$error=$obj_content->checkData($_POST,$id);

	if($error==""){

		if(isset($_GET['id']))

			$obj_content->updateData($_POST,$id);

		else 

			$obj_content->insertData($_POST);

	}

}

?>

<div>

	<ul class="breadcrumb">

		<li>

			<a href="index.php">Home</a> <span class="divider">/</span>

		</li>

		<li>

			<a href="index.php?p=content<?php if(isset($_GET['id']) && (int)$_GET['id']) echo '&id='.(int)$_GET['id'];?>"><?php if(isset($_GET['id'])) echo 'Edit Page'; else echo 'Add Page';?></a>

		</li>

	</ul>

</div>

<div class="row-fluid sortable">

	<div class="box span12">

		<div class="box-header well" data-original-title>

			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Page'; else echo 'Add Page';?></h2>

			<div class="box-icon">

				<a style="width:69px;" href="index.php?p=contents" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>

			</div>

		</div>

		<div class="box-content">			 

			<form id="edit" class="form-horizontal" name="frm" action="" method="post">

				<fieldset>

					<div class="control-group <?php if(strlen(trim($error))) echo 'error';?>">

					  <label class="control-label">Page Title</label>

					  <div class="controls">

						<input type="text" name="title" class="input-xlarge focused" value="<?php if(isset($_POST['title'])) echo $_POST['title'];?>">

						<?php if(strlen(trim($error))){?><span class="help-inline"><?php echo $error;?></span><?php } ?>

					  </div>

					</div>

					<div class="control-group">

					  <label class="control-label" for="textarea2">Content</label>

					  <div class="controls">

						<textarea class="ckeditor" id="editor1" name="content" rows="3"><?php if(isset($_POST['content'])) echo $_POST['content'];?></textarea>

					  </div> 

					</div>

					<div class="control-group">

						<label class="control-label" for="selectError">Add as Sub Page</label>

						<div class="controls">

						  <select name="parent" data-rel="chosen">

							<option value="">Select Parent</option>

							<?php $toplink=$db->fetchResult("SELECT * FROM ".TABLE_CONTENT." where parent=0 order by ord"); while($top=$db->fetchArray($toplink)){ ?>

							<option value="<?php echo $top['id'];?>" <?php if($top['id']==$_POST['parent']) echo 'selected="selected"';?>><?php echo str_replace("_"," ",$top['title']);?></option>

							<?php } ?> 

						  </select>

						</div>

					</div>

					<div class="control-group">

					  <label class="control-label">URL Alias Name</label>

					  <div class="controls">

						<?php 

							if(isset($_GET['id']) && (int)$_GET['id']){ 

								$query='page_id='.(int)$_GET['id'];

								$alias_row=$db->fetchRow("SELECT * FROM ".TABLE_ALIAS." WHERE query='".$query."'"); 

								$_POST['keyword']=$alias_row['keyword'];

							}

							else $_POST['keyword']='';							

						?>

						<input type="text" name="keyword" class="input-xlarge focused" value="<?php if(isset($_POST['keyword'])) echo $_POST['keyword'];?>">

					  </div>

					</div>

					<div class="control-group">

					  <label class="control-label">Sort Order</label>

					  <div class="controls">

						<input type="text" name="ord" class="input-xlarge focused" value="<?php if(isset($_POST['ord'])) echo $_POST['ord'];?>">

					  </div>

					</div>

					<div class="control-group">

						<label class="control-label">Position</label>

						<div class="controls">

						  <label class="checkbox inline" style="padding-left:0px;">

							<input type="checkbox" name="header" value="1" <?php if($_POST['header']==1) echo 'checked="checked"';?>> Header

						  </label>

						  <label class="checkbox inline" style="padding-left:0px;">

							<input type="checkbox" name="footer" value="1" <?php if($_POST['footer']==1) echo 'checked="checked"';?>> Footer

						  </label>						  

						</div>

					</div>	

					<div class="control-group">

						<div class="controls">

							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>

						</div>

					</div>

				</fieldset>

			</form>

		</div>

	</div><!--/span-->

</div><!--/row-->