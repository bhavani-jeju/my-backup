<?php

if(isset($_GET['id']) && (int)$_GET['id'] && $_GET['act']=="del"){

	$delete="delete from ".TABLE_USERS." where id=".(int)$_GET['id'];

	$db->fetchResult($delete);

	echo "<script>location.replace('index.php?p=users&msg=3');</script>";

}

?>

<div>

	<ul class="breadcrumb">

		<li>

			<a href="index.php">Home</a> <span class="divider">/</span>

		</li>

		<li>

			<a href="index.php?p=users">Users</a>

		</li>

	</ul>

</div>

<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>

	<div class="alert alert-success">

		<button type="button" class="close" data-dismiss="alert">×</button>

		<?php if($_GET['msg']==1){?>User added successfully.<?php } else if($_GET['msg']==2) {?>User updated successfully.<?php }else if($_GET['msg']==3) {?>User deleted successfully. <?php } ?>

	</div>

<?php } ?>       

<div class="row-fluid sortable">		

	<div class="box span12">

		<div class="box-header well" data-original-title>

			<h2><i class="icon-user"></i> Users Management</h2>			
<div class="box-icon">
            <a href="export1.php" style="width:93px;" class="btn btn-add btn-round"><i class="icon-plus"></i>Export</a>
			</div>
		</div>

		<div class="box-content">

			<table class="table table-striped table-bordered bootstrap-datatable datatable">

			  <thead>

				<tr>

				  <th>S.No</th>

				  <th>First Name</th>

				  <th>Last Name</th>

				  <th>Email</th>
                  
                   <th>Phone NO</th>

				  <th class="center">Actions</th>

				</tr>

			  </thead>

			  <tbody>

				<?php
$type="merchant";
					  $content_select_query="SELECT * FROM ".TABLE_USERS."  where type!='".$type."'ORDER BY id DESC";

					  $content_select_srows=$db->fetchNum($content_select_query);	

					  if($content_select_srows){					  

					  $j=1;

					  $content_select_res=$db->fetchResult($content_select_query);

					  while($content_select_srows=$db->fetchArray($content_select_res)) {

					?>

				<tr>

				  <td><?php echo $j++;?></td>

				  <td><?php echo $content_select_srows['firstname'];?></td>	

				  <td><?php echo $content_select_srows['lastname'];?></td>	

				  <td><?php echo $content_select_srows['email'];?></td>		
                  <td><?php echo $content_select_srows['telephone'];?></td>						  

				  <td class="center"> <a class="btn btn-success" href="index.php?p=user&id=<?php echo $content_select_srows['id'];?>">

										<i class="icon-zoom-in icon-white"></i>  

										Edit                                            

									</a>

									<a class="btn btn-danger" href="index.php?p=user&id=<?php echo $content_select_srows['id'];?>&act=del" onclick="if(!confirm('Are you sure you want to delete this user.')) return false;">

										<i class="icon-trash icon-white"></i> 

										Delete

									</a></td>

				</tr>

				 <?php } } else { ?>

					<tr>

						<td colspan="5" align="center" style="color:#F00; font-weight:bold;">

							No records found

						</td>

					</tr>

				<?php } ?>

			  </tbody>

			</table>

		</div>

	</div><!--/span-->

	

</div><!--/row-->      