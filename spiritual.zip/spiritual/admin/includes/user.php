<?php
if(!isset($_GET['id']) && !(int)$_GET['id']){
	echo "<script>location.replace('index.php?p=users');</script>";
}
if(isset($_POST['btn_submit'])){
	$q=mysql_query("update  users set firstname='".mysql_escape_string(stripslashes($_POST['fname']))."',lastname='".mysql_escape_string(stripslashes($_POST['lname']))."',email='".mysql_escape_string(stripslashes($_POST['email']))."',city='".mysql_escape_string(stripslashes($_POST['city']))."',status='".mysql_escape_string(stripslashes($_POST['status']))."' where id=".(int)$_GET['id']) or die(mysql_error());
	if($q){
		 echo "<script>location.replace('index.php?p=users&msg=2');</script>";
	}
}
$row=$db->fetchRow("SELECT * FROM ".TABLE_USERS." WHERE id=".(int)$_GET['id']);
?>
<div>
	<ul class="breadcrumb">
		<li>
			<a href="index.php">Home</a> <span class="divider">/</span>
		</li>
		<li>
			<a href="index.php?p=user&id=<?php echo $_GET['id'];?>">View User</a>
		</li>
	</ul>
</div>

<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header well" data-original-title>
			<h2><i class="icon-zoom-in"></i>View User</h2>
			<div class="box-icon">
				<a style="width:69px;" href="index.php?p=users" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>
			</div>
		</div>
		<div class="box-content">
			<div class="control-group">
            <form method="post">
				<table cellpadding="0" cellspacing="0" border="0">
					<tr>
						<th style="text-align:left;" width="100">First Name</th>
						<td width="20">:</td>
						<td><input type="text" name="fname" id="fname" value="<?php echo ucwords($row['firstname']);?>"/></td>
					</tr>
					<tr>
						<th style="text-align:left;" width="100">Last Name</th>
						<td >:</td>
						<td><input type="text" name="lname" id="lname" value="<?php echo ucwords($row['lastname']);?>"/></td>
					</tr>
					<tr>
						<th style="text-align:left;" width="100">Email Address</th>
						<td>:</td>
						<td><input type="text" name="email" id="email" value="<?php echo ucwords($row['email']);?>"/></td>
					</tr>
                    <tr>
						<th style="text-align:left;" width="100">City</th>
						<td width="20">:</td>
						<td><input type="text" name="city" id="city"  value="<?php echo ucwords($row['city']);?>"/></td>
					</tr>
                    
					<tr>
						<th style="text-align:left;" width="100">Password</th>
						<td>:</td>
						<td>
                        <input type="text" name="password" id="password"  value="<?php echo ucwords($row['password']);?>"/>
                        </td>
					</tr>
                    
                    <tr>
                    <td colspan="2" align="center">Bank Account details</td>
                    </tr>
                    <tr>
						<th style="text-align:left;" width="100">Bank Account No</th>
						<td>:</td>
						<td>
                        <input type="text" name="accno" id="accno" readonly="readonly"   value="<?php echo ucwords($row['accno']);?>" />
                        </td>
					</tr>
                    <tr>
						<th style="text-align:left;" width="100">Bsb No</th>
						<td>:</td>
						<td>
                        <input type="text" readonly="readonly"  name="accno" id="accno" 
                           value="<?php echo ucwords($row['accno']);?>"/>
                        </td>
					</tr>
                    <tr>
						<th style="text-align:left;" width="100">Account Name</th>
						<td>:</td>
						<td>
                        <input type="text"   name="accname"  readonly="readonly"   value="<?php echo ucwords($row['accname']);?>" />
                        </td>
					</tr>
                    <tr>
                    <td colspan="3" align="center">
                    <button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>
                    </td>
                    </tr>
				</table>
                </form>
			</div>
		</div>
	</div><!--/span-->

</div><!--/row-->