<?php

include("includes/classes/banner.php");

$obj_content=new content();

if(isset($_GET['id']) && !isset($_POST['btn_submit'])){

	$_POST=$obj_content->getData((int)$_GET['id']);

}

if(isset($_POST['btn_submit'])){

	$error=array();

	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";

	$error=$obj_content->checkData($_POST,$id);

	if(count($error)==0){

		if(isset($_GET['id']))

			$obj_content->updateData($_POST,$id);

		else 

			$obj_content->insertData($_POST);

	}

}

?>

<div>

	<ul class="breadcrumb">

		<li>

			<a href="index.php">Home</a> <span class="divider">/</span>

		</li>

		<li>

			<a href="index.php?p=banner<?php if(isset($_GET['id']) && (int)$_GET['id']) echo '&id='.(int)$_GET['id'];?>"><?php if(isset($_GET['id'])) echo 'Edit Banner'; else echo 'Add Banner';?></a>

		</li>

	</ul>

</div>

<div class="row-fluid sortable">

	<div class="box span12">

		<div class="box-header well" data-original-title>

			<h2><i class="icon-edit"></i><?php if(isset($_GET['id'])) echo 'Edit Banner'; else echo 'Add Banner';?></h2>

			<div class="box-icon">

				<a style="width:69px;" href="index.php?p=banners" class="btn btn-back btn-round"><i class="icon-chevron-left"></i>Back</a>

			</div>

		</div>

		<div class="box-content"> 

			<fieldset>

				<form id="edit" name="frm" action="" class="form-horizontal" method="post" enctype="multipart/form-data">

					<div class="control-group <?php if(strlen(trim($error['title']))) echo 'error';?>">

						<label class="control-label">Title</label>

						<div class="controls">

							<input type="text" name="title" value="<?php if(isset($_POST['title'])) echo $_POST['title'];?>" class="input-xlarge focused"  />

							<?php if(strlen(trim($error['title']))){?><span class="help-inline"><?php echo $error['title'];?></span><?php } ?>

						</div>

					</div>					

					<div class="control-group">

						<label class="control-label">Iframe Url</label>

						<div class="controls">

							<textarea rows="3" name="content" id="editor1" class="ckeditor"><?php if(isset($_POST['content'])) echo $_POST['content'];?></textarea>

						</div>

					</div>

					<div class="control-group <?php if(strlen(trim($error['img']))) echo 'error';?>">

						<label class="control-label">Vedio</label>

						<div class="controls">

							<input type="file" name="mimg" class="smallInput" />

							<?php if(strlen(trim($error['img']))){?><span class="help-inline"><?php echo $error['img'];?></span><?php } ?>

							<?php if(file_exists('../images/banners/imga'.$_POST['image'])){?><div class="product_image"><img src="../images/banners/imga<?php echo $_POST['image'];?>" width="50" height="50" /><input type="hidden" name="image" value="<?php echo $_POST['image'];?>" /><?php } ?>

						</div>

					</div>					

					<div class="control-group">

						<div class="controls">

							<button type="submit" name="btn_submit" value="submit" class="btn btn-primary">Save changes</button>

						</div>

					</div>

				</form>

			</fieldset>

		</div>

	</div><!--/span-->

</div><!--/row-->