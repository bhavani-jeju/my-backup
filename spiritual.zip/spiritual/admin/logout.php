<?php
session_start();
if(isset($_SESSION['adminuserid']) && strlen(trim($_SESSION['adminuserid']))){
session_destroy();
header("Location:login.php");
}
?>