<?php 
session_start(); 
include("../includes/config.php");
if(isset($_POST['btn_submit'])){
	$error='';
	if(!strlen(trim($_POST['username']))) $error.='Please enter Username.<br />';
	if(!strlen(trim($_POST['password']))) $error.='Please enter Password.';
	if($error==''){
		  $query="select * from ".TABLE_ADMIN." where username='".mysql_escape_string(stripslashes($_POST['username']))."' and password='".mysql_escape_string(stripslashes($_POST['password']))."'";
		  $row= $db->fetchRow($query);
		  $num= $db->fetchNum($query);
		  if($num){
			  $_SESSION['adminuserid']=$row['id'];
			  header("Location:index.php");
		  }
		  else $error.='Please enter valid details.';
	}
}

$no_visible_elements=true;
include('includes/header.php'); ?>

			<div class="row-fluid">
				<div class="span12 center login-header">
					<h2>Welcome to <?php echo SITE_NAME;?></h2>
				</div><!--/span-->
			</div><!--/row-->
			
			<div class="row-fluid">
				<div class="well span5 center login-box">
					<div class="alert alert-info">
						<?php 
						if(strlen(trim($error))){ echo '<span style="color:#F00;">"'.$error.'"</span>';} else {?>Please login with your Username and Password.<?php } ?>
					</div>
					<form class="form-horizontal" method="post">
						<fieldset>
							<div class="input-prepend" title="Username" data-rel="tooltip">
								<span class="add-on"><i class="icon-user"></i></span><input autofocus class="input-large span10" name="username" id="username" type="text" value="" />
							</div>
							<div class="clearfix"></div>

							<div class="input-prepend" title="Password" data-rel="tooltip">
								<span class="add-on"><i class="icon-lock"></i></span><input class="input-large span10" name="password" id="password" type="password" value="" />
							</div>
							<div class="clearfix"></div>

							

							<p class="center span5">
                            <a href="forgot.php" class="link">Forgotten Password</a><br />
							<button type="submit" value="Submit" name="btn_submit" class="btn btn-primary">Login</button>
							</p>
						</fieldset>
					</form>
				</div><!--/span-->
			</div><!--/row-->
<?php include('includes/footer.php'); ?>
