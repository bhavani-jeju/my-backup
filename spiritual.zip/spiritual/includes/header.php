<!DOCTYPE HTML>
<html>
<head>
<title>The Webworld-v2 Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/jquery.min.js"></script>
	 	<!---strat-slider---->
	    <link rel="stylesheet" type="text/css" href="css/slider.css" />
		<script type="text/javascript" src="js/modernizr.custom.28468.js"></script>
		<script type="text/javascript" src="js/jquery.cslider.js"></script>
			<script type="text/javascript">
				$(function() {
				
					$('#da-slider').cslider({
						autoplay	: true,
						bgincrement	: 450
					});
				
				});
			</script>
		<!---//strat-slider---->
<!-- start top_js_button -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
   <script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){		
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
			});
		});
	</script>
</head>
<body>
<!-- start header -->
<div class="header_bg">
<div class="wrap">
	<div class="header">
		<div class="logo">
			<a href=""><img src="images/logo.png" alt=""/> </a>
            <?php if(!isset($_SESSION['session_user_id']) || !isset($_SESSION['session_user_email'])){?>
   <div class="logo-right"> <p> <a href="<?php echo SITE_URL;?>login">Customer Login</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="<?php echo SITE_URL;?>register">Register</a><a href="<?php echo SITE_URL;?>dlogin">doctor Login</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="<?php echo SITE_URL;?>dregister">Register</a></p></div>
    <?php } else { 
			$userrow = $db->fetchRow("SELECT * FROM ".TABLE_USERS." WHERE email='".mysql_escape_string(stripslashes($_SESSION['session_user_email']))."'"); 
			?>
    <p> Call 0402576515 &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo SITE_URL;?>about">About Us</a> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo SITE_URL;?>contact"> Contact Us </a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
      <?php if($userrow ['type']=="merchant"){ ?>
      <a  href="<?php echo SITE_URL;?>/meraccount"> back to My Account</a>
      <?php } else{ ?>
      <a   href="<?php echo SITE_URL;?>my-account"> back to My Account</a>
      <?php } ?> 
      <?php 
	  
	  $userrow1 = $db->fetchRow("SELECT * FROM ".TABLE_USERS." WHERE id='".mysql_escape_string(stripslashes($_SESSION['session_user_id']))."'"); ?>
        Welcome <a href="<?php echo SITE_URL;?>profile"><strong><?php echo $userrow1['firstname'];?></strong></a> |<a href="<?php if ($user) echo $facebook->getLogoutUrl(array('next'=>SITE_URL.'logout?logout')); else echo SITE_URL.'logout?logout';?>"><strong>Logout</strong></a>
    <?php } ?>
		</div>
		<div class="social-icons">
		    <ul>
		      <li><a href="#" target="_blank"></a></li>
			  <li><a href="#" target="_blank"></a></li>
		      <li><a href="#" target="_blank"></a></li>
			  <li><a href="#" target="_blank"></a></li>
			</ul>
		</div>
		<div class="clear"></div>
	</div>
</div>
</div>
<!-- start header -->
<div class="header_btm">
<div class="wrap">
	<div class="header_sub">
		<div class="h_menu">
			<ul>
				<li class="active"><a href="">Home</a></li>
                <?php
				
				$q=mysql_query("select * from content where header='".(int)$a."'");
				$r=mysql_fetch_array($q);?>
				<li><a href="about.php">About us</a></li>
				<li><a href="service.html">Service</a></li>
				<li><a href="index.html">Pages</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="contact">Contact us</a></li>
			</ul>
		</div>
		<div class="h_search">
    		<form>
    			<input type="text" value="" placeholder="search something...">
    			<input type="submit" value="">
    		</form>
		</div>
        <div class="menu">
        	<ul>
				<li class="active"><a href="index.html">Home</a></li>
				<li><a href="about.html">About us</a></li>
				<li><a href="service.html">Service</a></li>
				<li><a href="index.html">Pages</a></li>
				<li><a href="blog.html">Blog</a></li>
				<li><a href="contact.html">Contact us</a></li>
            </ul>
        </div>
        <div class="search">
            <form action="/iphone/search.html">
                <input type="text" value="Search" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Search';}" class="text">
            </form>
        </div>
        <div class="sub-head">
        	<ul>
            	<li><a href="#" id="menu">Menu  <span></span></a></li>
            	<li><a href="#" id="search">Search <span></span></a></li>
            </ul>
            <div class="clear"></div>
        </div>
	   <script type="text/javascript">
		$(".menu,.search").hide();
		$("#menu").click(function(){
			$(".menu").toggle();
			$(".search").hide();
			$("#search").removeClass("active");
			$("#menu").toggleClass("active");
		});
		$("#search").click(function(){
			$(".search").toggle();
			$(".menu").hide();
			$("#menu").removeClass("active");
			$("#search").toggleClass("active");
			$(".text").focus();
		});
	</script>
	<script type="text/javascript" src="js/script.js"></script>
	<div class="clear"></div>

		<div class="clear"></div>
</div>
</div>
</div>
