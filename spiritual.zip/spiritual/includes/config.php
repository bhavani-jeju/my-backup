<?php 
class db{
	function connect(){
		$dbname='spiritual';
		$dbuser='root';
		$dbpass='';
		$dbhost='localhost';

    	$con=mysql_connect($dbhost,$dbuser,$dbpass);
		mysql_select_db($dbname	, $con);		
	}
	
	function fetchRow($query){
		$res=mysql_query($query) or die(mysql_error());
		$result=mysql_fetch_array($res);
		return $result;
	}
	
	function fetch_array($query){
		$result=mysql_fetch_array($query);
		return $result;
	}
	
	
	function fetchNum($query){
		$res=mysql_query($query) or die(mysql_error());
		$result=mysql_num_rows($res);
		return $result;
	}
	
	function fetchResult($query){
		$result=mysql_query($query) or die(mysql_error());
		return $result;
	}
		
	function fetchArray($query){
		$result=mysql_fetch_array($query);
		return $result;
	}
	
}

define("SITE_NAME","Spiritual Web");
define("SITE_URL","localhost/spiritual");
define("TABLE_ADMIN","admin");
define("TABLE_CONTENT","content");
define("TABLE_PRODUCTS","products");
define("TABLE_CATEGORIES","categories");
define("TABLE_COUNTRIES","countries");
define("TABLE_BRAND","brand");
define("TABLE_NEWS","news");
define("TABLE_NEWSLETTER","newsletter");
define("TABLE_SHIPPING","shipping_costs");
define("TABLE_TESTIMONIALS","testimonials");
define("TABLE_USERS","users");
define("TABLE_ORDERS","orders");
define("TABLE_CART","cart");
define("TABLE_BANNERS","banners");
define("TABLE_ARTICLES","articles");
define("TABLE_COUPONS","coupons");
define("TABLE_ALIAS","url_alias");
define("TABLE_ADDRESS","address");
define("TABLE_WISHLIST","wishlist");
define("TABLE_BILLING","billing");

$db = new db();
$db->connect();
date_default_timezone_set('Australia/Sydney');
class alias{
	function get_alias($keyword,$c=null,$qry=null){
		global $db;
		if((int)$c) $keyw = $keyword.'-'.$c; else{ $keyw=$keyword;$c=0;}	
		if(strlen(trim($qry))) $sqry="and query<>'".mysql_escape_string(stripslashes($qry))."'"; else $sqry="";
		$select="select id from ".TABLE_ALIAS." where keyword='".mysql_escape_string(stripslashes($keyw))."' $sqry";
		$num=$db->fetchNum($select);
		$cn = (int)$c+1;
		if($num) return $this->get_alias($keyword,$cn,$qry);
		else return $keyw;
	}
}
$alias = new alias();

class general{	
	function get_the_url($query){
		global $db;
		$select="select keyword from ".TABLE_ALIAS." where query='".mysql_escape_string(stripslashes($query))."'";
		if($db->fetchNum($select)){
			$row=$db->fetchRow($select);
			return SITE_URL.$row['keyword'];
		}
		else{
			$alias_pages = explode("=",$query);
			if($alias_pages[0]=='page_id'){ $route='content'; }
			if($alias_pages[0]=='coupon_id'){ $route='coupon'; }
			if($alias_pages[0]=='vedio_id'){ $route='product'; }
			if($alias_pages[0]=='company_id'){ $route='coupons'; }
			if($alias_pages[0]=='product_id'){ $route='product';}
			if($alias_pages[0]=='category_id'){ $route='products';}
			if($alias_pages[0]=='brand_id'){ $route='article'; }
			if($alias_pages[0]=='article_id'){ $route='article';}
			return SITE_URL.'index.php?route='.$route.'&'.$query;
		}
	}
	function get_meta($uri_array){
		global $db;
		if(isset($uri_array['_route_']) && strlen(trim($uri_array['_route_']))){
			$url_qry="SELECT * FROM ".TABLE_ALIAS." WHERE keyword='".mysql_escape_string(stripslashes($_GET['_route_']))."'";
			if($db->fetchNum($url_qry)){
				$url_row=$db->fetchRow($url_qry);
				$alias_pages = explode("=",$url_row['query']);
				
				if($alias_pages[0]=='page_id'){ $p='content'; $page_id=$alias_pages[1];}
				if($alias_pages[0]=='product_id'){ $p='product'; $product_id=$alias_pages[1];}
				if($alias_pages[0]=='vedio_id'){ $p='product'; $vedio_id=$alias_pages[1];}
				if($alias_pages[0]=='category_id'){ $p='products'; $category_id=$alias_pages[1];}
				if($alias_pages[0]=='company_id'){ $p='coupons'; $company_id=$alias_pages[1];}
				if($alias_pages[0]=='brand_id'){ $p='products'; $brand_id=$alias_pages[1];}
				if($alias_pages[0]=='article_id'){ $p='article'; $article_id=$alias_pages[1];}
			}
			else{
				$p=$_GET['_route_'];
			}
		}
		else if(isset($uri_array['route']) && strlen(trim($uri_array['route']))){
			if($uri_array['route']=='content' && isset($uri_array['page_id']) && (int)$uri_array['page_id']){ $p='content'; $page_id=$uri_array['page_id'];}
			if($uri_array['route']=='product' && isset($uri_array['vedio_id']) && (int)$uri_array['vedio_id']){ $p='product'; $vedio_id=$uri_array['vedio_id'];}
			if($uri_array['route']=='coupons' && isset($uri_array['company_id']) && (int)$uri_array['company_id']){ $p='coupons'; $page_id=$uri_array['company_id'];}
			if($uri_array['route']=='product' && isset($uri_array['product_id']) && (int)$uri_array['product_id']){ $p='product'; $product_id=$uri_array['product_id'];}
			if($uri_array['route']=='coupon' && isset($uri_array['coupon_id']) && (int)$uri_array['coupon_id']){ $p='coupon'; $coupon_id=$uri_array['coupon_id'];}
			if($uri_array['route']=='products' && isset($uri_array['category_id']) && (int)$uri_array['category_id']){ $p='products'; $category_id=$uri_array['category_id'];}
			if($uri_array['route']=='products' && isset($uri_array['brand_id']) && (int)$uri_array['brand_id']){ $p='products'; $brand_id=$uri_array['brand_id'];}
			if($uri_array['route']=='article' && isset($uri_array['article_id']) && (int)$uri_array['article_id']){ $p='article'; $article_id=$uri_array['article_id'];}
		}
		else{
			$p="home";
		}
		
		if($p=="home"){
			$meta_row = $db->fetchRow("SELECT mtitle,mkey,mdesc FROM ".TABLE_CONTENT." WHERE title='Home'");
			if(strlen(trim($meta_row['mtitle']))) $mtitle=$meta_row['mtitle']; else $mtitle=SITE_NAME;
			$meta = '<title>'.$mtitle.'</title><meta name="keywords" content="'.$meta_row['mkey'].'" /><meta name="description" content="'.$meta_row['mdesc'].'" />';
		}
		else if($p=='content' && (int)$page_id){
			$meta_row = $db->fetchRow("SELECT mtitle,mkey,mdesc FROM ".TABLE_CONTENT." WHERE id=".(int)$page_id);
			if(strlen(trim($meta_row['mtitle']))) $mtitle=$meta_row['mtitle']; else $mtitle=SITE_NAME;
			$meta = '<title>'.$mtitle.'</title><meta name="keywords" content="'.$meta_row['mkey'].'" /><meta name="description" content="'.$meta_row['mdesc'].'" />';
		}
		else if($p=='product' && (int)$product_id){
			$meta_row = $db->fetchRow("SELECT mtitle,mkey,mdesc FROM ".TABLE_PRODUCTS." WHERE id=".(int)$product_id);
			if(strlen(trim($meta_row['mtitle']))) $mtitle=$meta_row['mtitle']; else $mtitle=SITE_NAME;
			$meta = '<title>'.$mtitle.'</title><meta name="keywords" content="'.$meta_row['mkey'].'" /><meta name="description" content="'.$meta_row['mdesc'].'" />';
		}
		else{
			$meta = '<title>'.ucwords(str_replace('-',' ',$p)).'</title>';
		}
		return $meta;
	}
	
	function random_number()
	{
		global $db;
		$rnm = rand();
		$select="select id from ".TABLE_ORDERS." where rnm='".mysql_escape_string(stripslashes($rnm))."'";
		$num=$db->fetchNum($select);
		if($num) return $this->random_number();
		else return $rnm;
	}
	function set_session_message($msg)
	{
		$_SESSION['session_msg']=$msg;
	}
	function session_message()
	{
		if(isset($_SESSION['session_msg']))  echo $_SESSION['session_msg']; 
		unset($_SESSION['session_msg']);
	}
	function redirect($url)
	{
		echo "<script>location.replace('".$url."');</script>";
		exit;
	}
}
$general = new general();
?>