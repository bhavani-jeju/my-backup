<?php
if(!isset($_SESSION['session_user_id']) || !isset($_SESSION['session_user_email'])){
	$general->redirect(SITE_URL.'login');
}

if(isset($_POST['btn_profile'])){
	$upd_qry = "UPDATE ".TABLE_USERS." SET firstname='".mysql_escape_string(stripslashes($_POST['firstname']))."',
										   lastname='".mysql_escape_string(stripslashes($_POST['lastname']))."',sname='".mysql_escape_string(stripslashes($_POST['sname']))."',
										   telephone='".mysql_escape_string(stripslashes($_POST['telephone']))."',
										   fax='".mysql_escape_string(stripslashes($_POST['fax']))."'
										   WHERE email='".mysql_escape_string(stripslashes($_SESSION['session_user_email']))."'";
	$result = $db->fetchResult($upd_qry);
	if($result){	
		$general->set_session_message('<div class="success">Success. Your personal details updated successfully! <img class="close" alt="" src="'.SITE_URL.'images/close.png"></div>');
		$general->redirect(SITE_URL.'mprofile');
	}
}

$user_row = $db->fetchRow("SELECT * FROM ".TABLE_USERS." WHERE email='".mysql_escape_string(stripslashes($_SESSION['session_user_email']))."'");
?>
<div id="notification"><?php $general->session_message();?></div>
<div class="content">
 <h2>Your Personal Details</h2>
<form method="post" id="formID">
       <table width="100%" border="0" class="table_text">	
        <tbody>
        	<tr>
               <td width="22%">First Name<span class="required">*</span></td>
               <td width="4%">:</td>
               <td><input type="text" class="validate[required] input1" value="<?php echo $user_row['firstname'];?>" name="firstname"></td>
            </tr>
            <tr>
              <td>Last Name<span class="required">*</span></td>
              <td width="4%">:</td>
              <td><input type="text" class="validate[required] input1" value="<?php echo $user_row['lastname'];?>" name="lastname"></td>
            </tr>
            
            <tr>
              <td>E-Mail<span class="required">*</span></td>
              <td width="4%">:</td>
              <td><input type="text" value="<?php echo $user_row['email'];?>" name="email" readonly="readonly" class="input1"></td>
            </tr>
			 <tr>
              <td>Store Name<span class="required">*</span></td>
              <td width="4%">:</td>
              <td><input type="text" class="validate[required] input1" value="<?php echo $user_row['sname'];?>" name="sname"></td>
            </tr>
            <tr>
              <td>Telephone<span class="required">*</span></td>
              <td width="4%">:</td>
              <td><input type="text" class="validate[required] input1" value="<?php echo $user_row['telephone'];?>" name="telephone"></td>
            </tr>
            <tr>
              <td>Fax:</td>
              <td width="4%">:</td>
              <td><input type="text" value="<?php echo $user_row['fax'];?>" class="input1" name="fax"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
			  
			  	  <?php
		$q="SELECT *  FROM ".TABLE_USERS." WHERE email='".mysql_escape_string(stripslashes($_SESSION['session_user_email']))."'"; 
		$row = $db->fetchRow($q);
		?>
              <td><input type="submit" class="btn" name="btn_profile" value="Continue" />&nbsp; <?php if($row['type']=="customer"){ ?><a class="btn" style="padding:4.5px 10px" href="<?php echo SITE_URL;?>my-account">Back</a><?php } else{ ?><a class="btn" style="padding:4.5px 10px" href="<?php echo SITE_URL;?>meraccount">Back</a><?php } ?></td>
             </tr>
      	</tbody>
     </table>
  </form>
</div>