<?php
if(isset($_POST['btn_submit'])){
	$row = $db->fetchRow("select email from ".TABLE_ADMIN);   
	$to = $row['email'];
	$from = $_POST['email'];
	$subject = $_POST['subject'].' : '.SITE_NAME;
	$message='<table width="70%"  cellspacing="0" cellpadding="5" border="0" style="border:1px solid #d9d9d9">
				<tr>
				  <td style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-size:12px; padding:5px;background:#393939">Contact Details from '.SITE_NAME.'</td>
				</tr>
				<tr>
					<td style="border-top:1px solid #d9d9d9;border-bottom:1px solid #d9d9d9">
						<table width="100%" cellspacing="0" cellpadding="5" border="0">
							<tr>
								<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									Full Name
								</td>  
								<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									'.$_POST['name'].'
								</td>                
							</tr>  
							<tr>
								<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									Phone Number
								</td>  
								<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									'.$_POST['phone'].'
								</td>                
							</tr>  
							<tr>
								<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									Email Address
								</td>  
								<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									'.$_POST['email'].'
								</td>                
							</tr>  
							<tr>
								<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									Message
								</td>  
								<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									'.$_POST['message'].'
								</td>                
							</tr>              
						</table>
					</td>
				</tr>
				<tr>
					<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px;background:#eeeeee; padding-right:10px; line-height:30px;">Regards,<br />'.SITE_NAME.' Team</td>
				</tr>
			</table>';
	
	$headers = "From: ".$from." <".$from.">\n";
	$headers .= "X-Sender: <".$from.">\n";
	$headers .= "X-Mailer: PHP\n"; // mailer
	$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
	$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
			
	$sent = mail($to,$subject,$message,$headers);
	
	$subject = 'Contact Us Confirmation : '.SITE_NAME;
	$message='<table width="70%" cellspacing="0" cellpadding="5" border="0" style="border:1px solid #d9d9d9">
				<tr>
				  <td style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-size:12px; padding:5px;background:#393939">Contact Details from '.SITE_NAME.'</td>
				</tr>
				<tr>
					<td style="border-top:1px solid #d9d9d9;border-bottom:1px solid #d9d9d9">
						<table width="100%" cellspacing="0" cellpadding="5" border="0">
							<tr>
								<td width="100%" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
									Thank you for contact us. Our sales team wil contact within you 24 hours
								</td>             
							</tr>  							            
						</table>
					</td>
				</tr>
				<tr>
					<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px;background:#eeeeee; padding-right:10px; line-height:30px;">Regards,<br />'.SITE_NAME.' Team</td>
				</tr>
			</table>';
	
	$headers = "From: ".$to." <".$to.">\n";
	$headers .= "X-Sender: <".$to.">\n";
	$headers .= "X-Mailer: PHP\n"; // mailer
	$headers .= "Return-Path: <".$to.">\n"; // Return path for errors
	$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
			
	$sent1 = mail($from,$subject,$message,$headers);
	if($sent && $sent1){
		$general->set_session_message('<div class="success">Thank you for contact us. Our sales team wil contact you within 24 hours. <img class="close" alt="" src="'.SITE_URL.'images/close.png"></div>');
		$general->redirect(SITE_URL.'contact');
	}
}
?>
<div id="notification"><?php $general->session_message();?></div>
<div class="content">
	<h2>Contact Us</h2>
    <div>
<div >
    <form id="formID" method="post">
	 <table width="100%" border="0" class="table_text">	
            <tr>
                <td width="26%">Full Name<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="text" class="validate[required] input1" name="name" id="name" /></td>
			</tr>
			<tr>
                <td width="22%">Phone Number<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="text" class="validate[required] input1" name="phone" id="phone" /></td>
            </tr>
            <tr>
                <td width="22%">Email Address<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="text" class="validate[required,custom[email]] input1" name="email" id="email" /></td>
            </tr>
            <tr>
                <td width="22%">Subject<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="text" class="validate[required] input1" name="subject" id="subject" /></td>
            </tr>
            <tr>
                <td width="22%">Message<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><textarea name="message" class="validate[required] input1" id="message"></textarea></td>
            </tr>
            <tr> 
            	 <td>&nbsp;</td>
          		<td>&nbsp;</td>
                <td><input class="btn" type="submit" name="btn_submit" value="Submit"/></td>
			</tr>
		</table>
    </form>
    </div>
    </div>
    <div style="clear:both;"></div>
</div>	