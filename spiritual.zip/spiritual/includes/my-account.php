<?php

if(!isset($_SESSION['session_user_id']) || !isset($_SESSION['session_user_email'])){

	$general->redirect(SITE_URL.'login');

}

?>

<div class="content">

  <h2>My Account</h2>

   <table width="100%" border="0" class="table_text">

   	<tr>

    	<td><a class="link" href="<?php echo SITE_URL;?>profile">Edit your account information</a></td>

    </tr>

    <tr>

    	<td><a class="link" href="<?php echo SITE_URL;?>change-password">Change your password</a></td>

    </tr>
    <tr>

    	<td><a class="link" href="<?php echo SITE_URL;?>baccount">Bank Account Information</a></td>

    </tr>
    <tr>

    	<td><a class="link" href="<?php echo SITE_URL;?>orders">View Your Order History</a></td>

    </tr>

    <tr>

    	<td><a class="link" href="<?php echo SITE_URL;?>address">Modify your address book entries</a></td>

    </tr>

    

  </table>

 

</div>