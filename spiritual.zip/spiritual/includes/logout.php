<?php
session_start();
session_destroy();
$db->fetchResult("DELETE FROM ".TABLE_CART." WHERE rnm='".$_SESSION['session_rnm']."'");
$general->redirect(SITE_URL.'login');
?>