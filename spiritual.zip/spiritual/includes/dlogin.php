<?php
if(isset($_SESSION['session_user_id']) && isset($_SESSION['session_user_email'])){
	$general->redirect(SITE_URL.'meraccount');
}
if(isset($_POST['btn_login'])){
$type="merchant";
	$sel_qty = "SELECT id FROM ".TABLE_USERS." WHERE email='".mysql_escape_string(stripslashes($_POST['email']))."' and password='".mysql_escape_string(stripslashes($_POST['password']))."' and type='".$type."' and featured=".(int)1;
	if($db->fetchNum($sel_qty)){
		$user_row = $db->fetchRow($sel_qty);
		$_SESSION['session_user_id'] = $user_row['id'];
		$_SESSION['session_user_email'] = $_POST['email'];
		$general->redirect(SITE_URL.'meraccount');
	}
	else{
		$general->set_session_message('<div class="warning">Sorry. Your email address or password appeared to be wrong!. <img class="close" alt="" src="'.SITE_URL.'images/close.png"></div>');
	}
}
?>
<div id="notification"><?php $general->session_message();?></div>
<div class="content">
    <div class="left" style="width:50%; float:left;">
      <h2>New Merchant</h2>
      <table width="100%" border="0" class="table_text">	
        <tr>
       		<td><b>Register Account</b></td>
        </tr>
        <tr>
        	<td>
        		By creating an account you will be able to shop faster, be up to date on an order's status, and keep track of the orders you have previously made.<br /><br />
        		<a class="btn" href="<?php echo SITE_URL;?>mregister">Continue</a>
            </td>
         </tr>
      </table>
    </div>
    <div class="right" style="width:50%; float:left;">
      <h2 style="padding-left:0px;">Returning Merchant</h2>
      <form id="formID" method="post">
        <table width="100%" border="0" class="table_text">	
          <tr>
       		<td colspan="3"><b>I am a returning merchant</td>
            </tr>
            <tr>
                <td width="22%">E-Mail Address<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="text" class="validate[required,custom[email]] input1" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>" /></td>
            </tr>
              <tr>
                <td width="22%">Password<span class="required">*</span></td>
                <td width="4%">:</td>
                <td width="74%"><input type="password" class="validate[required] input1" name="password"></td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td><a href="<?php echo SITE_URL;?>forgot" class="link">Forgotten Password</a></td>
             </tr>
             <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td><input type="submit" class="btn" name="btn_login" value="Login"></td>
               </tr>
         </table>
      </form>
    </div>
    <div style="clear:both;"></div>
</div>