<?php
if(isset($_POST['btn_forgot'])){
	$sel_qry = "SELECT password FROM ".TABLE_USERS." WHERE email='".mysql_escape_string(stripslashes($_POST['email']))."'";
	$result = $db->fetchRow($sel_qry);
	if(strlen(trim($result['password']))){
		$row = $db->fetchRow("select email from ".TABLE_ADMIN);   
		$from = $row['email'];
		$to = $_POST['email'];
		$subject = 'Forgotten Password : '.SITE_NAME;
		$message='<table width="70%"  cellspacing="0" cellpadding="5" border="0" style="border:1px solid #d9d9d9">
					<tr>
					  <td style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-size:12px; padding:5px;background:#393939">Your Password Details from '.SITE_NAME.'</td>
					</tr>
					<tr>
						<td style="border-top:1px solid #d9d9d9;border-bottom:1px solid #d9d9d9">
							<table width="100%" cellspacing="0" cellpadding="5" border="0">
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Your Password
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$result['password'].'
									</td>                
								</tr>      
							</table>
						</td>
					</tr>
					<tr>
						<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px;background:#eeeeee; padding-right:10px; line-height:30px;">Regards,<br />'.SITE_NAME.' Team</td>
					</tr>
				</table>';
		
		$headers = "From: ".$from." <".$from.">\n";
		$headers .= "X-Sender: <".$from.">\n";
		$headers .= "X-Mailer: PHP\n"; // mailer
		$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
		$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
				
		$sent = mail($to,$subject,$message,$headers);
	
		$general->set_session_message('<div class="success">Success. Your password has been sent to your email address! <img class="close" alt="" src="'.SITE_URL.'images/close.png"></div>');
		$general->redirect(SITE_URL.'mlogin');
	}
	
}
?>
<div id="notification"><?php $general->session_message();?></div>
<div class="content">
  <h2>Forgot Your Password?</h2>
  <form method="post" id="formID">
    <table width="100%" border="0" class="table_text">	
        <tr>
        	<td colspan="3">Enter the e-mail address associated with your account. Click submit to have your password e-mailed to you.</td>
        </tr>
        <tr>
            <td width="22%">E-Mail Address<span class="required">*</span></td>
            <td width="4%">:</td>
            <td width="74%"><input type="text" class="validate[required,custom[email],ajax[ajaxForgotCallPhp]] input1" name="email" /></td>
        </tr>
         <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><input type="submit" class="btn" name="btn_forgot" value="Continue" />&nbsp;<a class="btn" style="padding:4.5px 10px" href="<?php echo SITE_URL;?>mlogin">Back</a></td>
         </tr>
      </tbody>
    </table>
  </form>
</div>