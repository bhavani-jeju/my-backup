<?php


function make_thumb($img_name,$filename,$new_w,$new_h,$ext)

{		

		if(!strcmp("jpg",$ext) || !strcmp("jpeg",$ext))

			$src_img=imagecreatefromjpeg($img_name);
		if(!strcmp("png",$ext))
			$src_img=imagecreatefrompng($img_name);

		if(!strcmp("GIF",$ext) || !strcmp("gif",$ext))

			$src_img=imagecreatefromgif($img_name);

			

		$old_x=imagesx($src_img);

		$old_y=imagesy($src_img);	

		

		$thumb_w=$new_w;

		$thumb_h=$new_h;

		//Ratio 

		//$new_width = $thumb_w;

		//$new_height = floor( $old_y* ( $thumb_w/ $old_x) );

		

		//$thumb_w=$new_width ;

		//$thumb_h=$new_height ;

		

		$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);

		if(!strcmp("png",$ext)){

			imagealphablending($dst_img,false);

   			imagesavealpha($dst_img,true);

			$transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

     		imagefilledrectangle($dst_img, 0, 0, $thumb_w, $thumb_h, $transparent);

		}

		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		if(!strcmp("png",$ext))			

			imagepng($dst_img,$filename);

		else

		imagejpeg($dst_img,$filename);

		imagedestroy($dst_img);

		imagedestroy($src_img);

}
if(isset($_POST['password'])){
$code=time();
$type="merchant";
	$ins_qty = "INSERT INTO ".TABLE_USERS." SET email='".mysql_escape_string(stripslashes($_POST['email']))."',
												password='".mysql_escape_string(stripslashes($_POST['password']))."',
												firstname='".mysql_escape_string(stripslashes($_POST['firstname']))."',
												lastname='".mysql_escape_string(stripslashes($_POST['lastname']))."',sname='".mysql_escape_string(stripslashes($_POST['sname']))."',
												telephone='".mysql_escape_string(stripslashes($_POST['telephone']))."',ano='".mysql_escape_string(stripslashes($_POST['ano']))."',
												fax='".mysql_escape_string(stripslashes($_POST['fax']))."',
												address1='".mysql_escape_string(stripslashes($_POST['address1']))."',
												address2='".mysql_escape_string(stripslashes($_POST['address2']))."',
												city='".mysql_escape_string(stripslashes($_POST['city']))."',
												state='".mysql_escape_string(stripslashes($_POST['state']))."',
												country='".mysql_escape_string(stripslashes($_POST['country']))."',code='".(int)$code."',
												postcode='".mysql_escape_string(stripslashes($_POST['postcode']))."',
												status='1',featured='0',type='".$type."'";
	$result = $db->fetchResult($ins_qty);
		if($result){
					
		
		$row = $db->fetchRow("select email from ".TABLE_ADMIN);   
		$to = $row['email'];
		$from = $_POST['email'];
		$subject = 'New Merchant registration : '.SITE_NAME;
		$message='<table width="70%"  cellspacing="0" cellpadding="5" border="0" style="border:1px solid #d9d9d9">
					<tr>
					  <td style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-size:12px; padding:5px;background:#393939">Registration Details from '.SITE_NAME.'</td>
					</tr>
					<tr>
						<td style="border-top:1px solid #d9d9d9;border-bottom:1px solid #d9d9d9">
							<table width="100%" cellspacing="0" cellpadding="5" border="0">
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										First Name
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['firstname'].'
									</td>                
								</tr>
								
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Last Name
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['lastname'].'
									</td>                
								</tr>  
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Email Address
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['email'].'
									</td>                
								</tr>  
									<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Store Name
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['sname'].'
									</td>                
								</tr>
																<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Password
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										You have entered
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Phone Number
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['telephone'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Fax
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['fax'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Address 1
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['address1'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Address 2
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['address2'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										City
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['city'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										State
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['state'].'
									</td>                
								</tr> 
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Country
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['country'].'
									</td>                
								</tr>    
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Post Code
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['postcode'].'
									</td>                
								</tr>  
								<tr>
									<td width="110px" style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										Shippingcost:
									</td>  
									<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px">
										'.$_POST['scost'].'
									</td>                
								</tr>           
							</table>
						</td>
					</tr>
					<tr>
						<td style="font-family:Arial, Helvetica, sans-serif;color:#000;font-size:12px;background:#eeeeee; padding-right:10px; line-height:30px;">Regards,<br />'.SITE_NAME.' Team</td>
					</tr>
				</table>';
		
		$headers = "From: ".$from." <".$from.">\n";
		$headers .= "X-Sender: <".$from.">\n";
		$headers .= "X-Mailer: PHP\n"; // mailer
		$headers .= "Return-Path: <".$from.">\n"; // Return path for errors
		$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
				
		$sent = mail($to,$subject,$message,$headers);
		
		$subject = 'Registration Confirmation: '.SITE_NAME;
		$headers = "From: ".$to." <".$to.">\n";
		$headers .= "X-Sender: <".$to.">\n";
		$headers .= "X-Mailer: PHP\n"; // mailer
		$headers .= "Return-Path: <".$to.">\n"; // Return path for errors
		$headers .= "Content-Type: text/html; charset=iso-8859-1\n"; // Mime type
		
		$sent1 = mail($from,$subject,$message,$headers);
	
		$general->set_session_message('<div class="success">Success. Your have registered successfully, Confirmation will be sent to your email address! <img class="close" alt="" src="'.SITE_URL.'images/close.png"></div>');
		$general->redirect(SITE_URL.'mlogin');
	}
	
}
?>
<div id="notification"><?php $general->session_message();?></div>
<div class="content">
  <h2>Register Account</h2>
  <form id="formID" method="post">
    <table width="100%" border="0" class="table_text">
	   	<tr>
       		<td colspan="3"><b>Your Personal Details</b></td>
        </tr>	
        <tr>
       		<td colspan="3">If you already have an account with us, please login at the <a class="link" href="<?php echo SITE_URL;?>mlogin">login page</a>.</td>
        </tr>
        <tr>
          <td width="22%">First Name<span class="required">*</span></td>
          <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="firstname"></td>
        </tr>
        <tr>
          <td>Last Name<span class="required">*</span> </td>
          <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="lastname"></td>
        </tr>
        <tr>
          <td>E-Mail<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="text" class="validate[required,custom[email],ajax[ajaxRegisterCallPhp]] input1" name="email"></td>
        </tr>
		 <tr>
          <td>Business Name<span class="required">*</span> </td>
          <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="sname"></td>
        </tr>
        <tr>
          <td>ABN No<span class="required">*</span> </td>
          <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="ano"></td>
        </tr>
        
		<tr>
          <td>Telephone<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="telephone"></td>
        </tr>
        <tr>
          <td>Fax:</td>
           <td width="4%">:</td>
          <td><input type="text" value="" name="fax" class="input1"></td>
        </tr>
        <tr>
       		<td colspan="3"><b>Your Address </b></td>
        </tr>
        <tr>
          <td>Address 1:</td>
           <td width="4%">:</td>
          <td><input type="text" value="" name="address1" class="input1"></td>
        </tr>
        <tr>
          <td>Address 2:</td>
           <td width="4%">:</td>
          <td><input type="text" value="" name="address2" class="input1"></td>
        </tr>
        <tr>
          <td>City<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="city">
            </td>
        </tr>
        <tr>
          <td>Post Code<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="postcode">
            </td>
        </tr>
        <tr>
          <td>Country<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><select name="country" class="validate[required] input1" style="width:212px;">
                <option value="">Select Country</option>
                <?php $toplink=$db->fetchResult("SELECT * FROM ".TABLE_COUNTRIES." order by id"); while($top=$db->fetchArray($toplink)){ ?>
                <option value="<?php echo $top['country_name'];?>"><?php echo $top['country_name'];?></option>
                <?php } ?>
            </select></td>
        </tr>
        <tr>
          <td>Region / State<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="text" class="validate[required] input1" name="state"></td>
        </tr>
        <tr>
       		<td colspan="3"><b>Your Password</b></td>
        </tr>
        <tr>
          <td>Password<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="password" id="password" class="validate[required] input1" name="password"></td>
        </tr>
        <tr>
          <td>Password Confirm<span class="required">*</span></td>
           <td width="4%">:</td>
          <td><input type="password" class="validate[required,equals[password] input1" name="confirm"></td>
        </tr>
        <tr>
           <td>&nbsp;</td>
           <td>&nbsp;</td>
          <td><input type="checkbox" class="validate[required]" value="1" name="agree"> I have read and agree to the <a class="link" alt="Privacy Policy" target="_blank" href="<?php echo $general->get_the_url('page_id=23');?>">Privacy Policy</a></td>
		</tr>		
		<tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td><input type="submit" class="btn" name="btn_register" value="Register"></td>
        </tr>
	</table>
      </form>
</div>